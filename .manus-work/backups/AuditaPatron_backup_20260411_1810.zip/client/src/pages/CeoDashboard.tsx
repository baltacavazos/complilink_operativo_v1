import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout, { type DashboardNavigationItem } from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { trackCeoConsoleViewed, trackCeoExport, trackCeoGuardrail, trackCeoMasterMetricsViewed, trackCeoRefresh } from "@/lib/analytics";
import { trpc } from "@/lib/trpc";
import { buildBridgeMonitoringPanel } from "@/pages/ceoBridgeMonitoring";
import { downloadCeoCsvReport, downloadCeoPdfReport, getCeoExportBlockReason } from "@/pages/ceoDashboardExports";
import {
  buildAuditExecutiveAlerts,
  buildAuditMonitoringSummary,
  filterAuditFeed,
  getAuditActionLabel,
  getAuditActionTone,
  getAuditDrilldownDescriptor,
  getAuditEventSeverity,
  getAuditFamilyLabel,
  getAuditRejectionReason,
  getAuditSeverityLabel,
  type AuditEventFamily,
  type AuditEventSeverity,
  type AuditExecutiveAlert,
  type AuditFeedItem,
} from "@/pages/ceoDashboardMonitoring";
import {
  AlertTriangle,
  ArrowLeft,
  Building2,
  Clock3,
  Files,
  Filter,
  GitBranch,
  LayoutDashboard,
  Loader2,
  RefreshCw,
  Search,
  ShieldCheck,
  ShieldX,
  Siren,
  UsersRound,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast as sonnerToast } from "sonner";
import { useLocation } from "wouter";

function formatNumber(value: number) {
  return new Intl.NumberFormat("es-MX").format(value ?? 0);
}

function formatDateTime(value: Date | string | null | undefined) {
  if (!value) return "Sin fecha";
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "Sin fecha";

  return new Intl.DateTimeFormat("es-MX", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
}

function getSeverityBadgeClass(severity: string) {
  switch (severity) {
    case "critical":
      return "border-rose-200 bg-rose-50 text-rose-700";
    case "high":
      return "border-orange-200 bg-orange-50 text-orange-700";
    case "medium":
      return "border-amber-200 bg-amber-50 text-amber-700";
    default:
      return "border-slate-200 bg-slate-100 text-slate-700";
  }
}

function getStatusBadgeClass(status: string) {
  switch (status) {
    case "active":
    case "open":
      return "border-emerald-200 bg-emerald-50 text-emerald-700";
    case "paused":
    case "pending":
    case "acknowledged":
      return "border-amber-200 bg-amber-50 text-amber-700";
    case "disabled":
    case "resolved":
    case "revoked":
      return "border-slate-200 bg-slate-100 text-slate-700";
    default:
      return "border-slate-200 bg-slate-100 text-slate-700";
  }
}

function getBridgeHealthBadgeClass(health: string) {
  switch (health) {
    case "healthy":
      return "border-emerald-200 bg-emerald-50 text-emerald-700";
    case "pending":
      return "border-sky-200 bg-sky-50 text-sky-700";
    case "warning":
      return "border-amber-200 bg-amber-50 text-amber-700";
    case "critical":
      return "border-rose-200 bg-rose-50 text-rose-700";
    default:
      return "border-slate-200 bg-slate-100 text-slate-700";
  }
}

function getBridgeOutcomeLabel(outcome: string) {
  if (outcome === "success") return "Retorno conforme";
  if (outcome === "retry_scheduled") return "Reintento programado";
  if (outcome === "permanent_failure") return "Fallo permanente";
  if (outcome === "skipped") return "Envío omitido";
  if (outcome === "pending_return") return "Esperando retorno";
  if (outcome === "warning") return "Con advertencias";
  return "Sin clasificar";
}

function getSafeNextAlertStatus(status: string) {
  if (status === "open") return "acknowledged" as const;
  if (status === "acknowledged") return "resolved" as const;
  return null;
}

function getSafeAlertActionLabel(status: string) {
  if (status === "open") return "Acusar recibo";
  if (status === "acknowledged") return "Marcar resuelta";
  return null;
}

function getSafeNextCaseStatus(status: string) {
  if (status === "intake") return "analysis" as const;
  if (status === "analysis") return "conciliation" as const;
  if (status === "conciliation") return "litigation" as const;
  return null;
}

function getSafeCaseActionLabel(status: string) {
  if (status === "intake") return "Pasar a análisis";
  if (status === "analysis") return "Pasar a conciliación";
  if (status === "conciliation") return "Pasar a litigio";
  return null;
}

function getSafeMembershipAction(membership: { status: string; accessScope: string; caseId?: string | null }) {
  if (membership.accessScope !== "case" || !membership.caseId) return null;
  if (membership.status === "active") {
    return { status: "revoked" as const, label: "Revocar acceso" };
  }
  return null;
}

type PendingExecutiveAction =
  | {
      kind: "alert";
      alertId: number;
      title: string;
      currentStatus: "open" | "acknowledged" | "resolved";
      nextStatus: "acknowledged" | "resolved";
      actionLabel: string;
    }
  | {
      kind: "membership";
      membershipId: number;
      userLabel: string;
      currentStatus: "active" | "revoked";
      nextStatus: "active" | "revoked";
      actionLabel: string;
    }
  | {
      kind: "case";
      tenantId: string;
      caseId: string;
      title: string;
      currentStatus: "intake" | "analysis" | "conciliation" | "litigation" | "archived";
      nextStatus: "analysis" | "conciliation" | "litigation";
      actionLabel: string;
    };

function getSafeActionErrorMessage(error: unknown) {
  const message = error instanceof Error ? error.message : "";

  if (/han cambiado|desactualizada/i.test(message)) {
    return "La vista quedó desactualizada. Refresca el panel antes de intentar de nuevo.";
  }
  if (/siguiente cambio operativo seguro|transición solicitada no es válida/i.test(message)) {
    return "El backend bloqueó un cambio fuera de la secuencia segura permitida por la consola CEO.";
  }
  if (/fuera del caso visible|acotados a un caso/i.test(message)) {
    return "Este bloque sólo permite operar accesos ligados a un caso visible y trazable.";
  }
  if (/permission|FORBIDDEN|10002/i.test(message)) {
    return "Tu sesión ya no tiene permisos suficientes para ejecutar esta acción.";
  }

  return "Intenta nuevamente en unos segundos.";
}

function KpiCard({
  label,
  value,
  helper,
}: {
  label: string;
  value: number;
  helper: string;
}) {
  return (
    <article className="rounded-3xl border border-white/70 bg-white/92 p-5 shadow-[0_24px_70px_-34px_rgba(15,23,42,0.24)] backdrop-blur">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">{label}</p>
      <div className="mt-3 flex items-end justify-between gap-3">
        <strong className="text-3xl font-semibold tracking-tight text-slate-950">{formatNumber(value)}</strong>
        <span className="text-right text-sm leading-5 text-slate-500">{helper}</span>
      </div>
    </article>
  );
}

function SectionEmptyState({
  title,
  description,
  onClear,
}: {
  title: string;
  description: string;
  onClear: () => void;
}) {
  return (
    <div className="rounded-[1.5rem] border border-dashed border-slate-300 bg-slate-50/80 px-5 py-8 text-center">
      <p className="text-base font-semibold text-slate-950">{title}</p>
      <p className="mx-auto mt-2 max-w-2xl text-sm leading-6 text-slate-600">{description}</p>
      <Button variant="outline" className="mt-4 rounded-full bg-white" onClick={onClear}>
        <X className="mr-2 h-4 w-4" />
        Limpiar filtros
      </Button>
    </div>
  );
}

type SectionKey = "resumen" | "bridge" | "alertas" | "accesos" | "documentos";

type FilterState = {
  tenantId: string;
  severity: string;
  caseId: string;
  userId: string;
  dateWindowDays: string;
};

const DEFAULT_FILTER_STATE: FilterState = {
  tenantId: "all",
  severity: "all",
  caseId: "all",
  userId: "all",
  dateWindowDays: "all",
};

const DATE_WINDOW_OPTIONS = [
  { value: "7", label: "Últimos 7 días" },
  { value: "30", label: "Últimos 30 días" },
  { value: "90", label: "Últimos 90 días" },
  { value: "365", label: "Últimos 12 meses" },
];

const AUDIT_FAMILY_FILTER_OPTIONS: Array<{ value: AuditEventFamily; label: string }> = [
  { value: "all", label: "Todos" },
  { value: "guardrail", label: "Guardrails" },
  { value: "document", label: "Documentos" },
  { value: "access", label: "Accesos" },
  { value: "policy", label: "Políticas" },
];

const AUDIT_SEVERITY_FILTER_OPTIONS: Array<{ value: AuditEventSeverity; label: string }> = [
  { value: "all", label: "Toda severidad" },
  { value: "high", label: "Alta" },
  { value: "medium", label: "Media" },
  { value: "normal", label: "Normal" },
];

function getCurrentSectionCount(
  section: SectionKey,
  snapshot: {
    tenantHealth: unknown[];
    recentCases: unknown[];
    recentAlerts: unknown[];
    recentMemberships: unknown[];
    recentDocuments: unknown[];
  } | null | undefined,
) {
  if (!snapshot) return 0;
  if (section === "alertas") return snapshot.recentAlerts.length;
  if (section === "accesos") return snapshot.recentMemberships.length;
  if (section === "documentos") return snapshot.recentDocuments.length;
  return snapshot.tenantHealth.length + snapshot.recentCases.length + snapshot.recentAlerts.length + snapshot.recentMemberships.length + snapshot.recentDocuments.length;
}

function getSectionLabel(section: SectionKey) {
  if (section === "bridge") return "Bridge operativo";
  if (section === "alertas") return "Alertas";
  if (section === "accesos") return "Accesos";
  if (section === "documentos") return "Documentos";
  return "Resumen CEO";
}

export default function CeoDashboard() {
  const auth = useAuth({ redirectOnUnauthenticated: true, redirectPath: "/ceo" });
  const { user, isViewingAsUser, loading } = auth;
  const [location, setLocation] = useLocation();
  const isAdmin = user?.role === "admin";

  useEffect(() => {
    if (loading || !isViewingAsUser) return;
    if (typeof window === "undefined") return;
    if (!window.location.pathname.startsWith("/ceo")) return;

    window.location.replace("/auditar");
  }, [isViewingAsUser, loading]);

  const utils = trpc.useUtils();
  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTER_STATE);
  const [auditFamilyFilter, setAuditFamilyFilter] = useState<AuditEventFamily>("all");
  const [auditSeverityFilter, setAuditSeverityFilter] = useState<AuditEventSeverity>("all");
  const [queryDraft, setQueryDraft] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [exportKind, setExportKind] = useState<"csv" | "pdf" | null>(null);
  const [pendingExecutiveAction, setPendingExecutiveAction] = useState<PendingExecutiveAction | null>(null);
  const [snapshotPulseAt, setSnapshotPulseAt] = useState(() => Date.now());

  useEffect(() => {
    const timeout = window.setTimeout(() => {
      setDebouncedQuery(queryDraft.trim());
    }, 300);

    return () => {
      window.clearTimeout(timeout);
    };
  }, [queryDraft]);

  useEffect(() => {
    const interval = window.setInterval(() => {
      setSnapshotPulseAt(Date.now());
    }, 30000);

    return () => {
      window.clearInterval(interval);
    };
  }, []);

  const currentSection = useMemo<SectionKey>(() => {
    if (location.startsWith("/ceo/bridge")) return "bridge";
    if (location.startsWith("/ceo/alertas")) return "alertas";
    if (location.startsWith("/ceo/accesos")) return "accesos";
    if (location.startsWith("/ceo/documentos")) return "documentos";
    return "resumen";
  }, [location]);

  const snapshotFilters = useMemo(() => {
    const input: {
      tenantId?: string;
      severity?: string;
      caseId?: string;
      userId?: number;
      dateWindowDays?: 7 | 30 | 90 | 365;
      query?: string;
    } = {};

    if (filters.tenantId !== "all") input.tenantId = filters.tenantId;
    if (filters.severity !== "all") input.severity = filters.severity;
    if (filters.caseId !== "all") input.caseId = filters.caseId;
    if (filters.userId !== "all") input.userId = Number(filters.userId);
    if (filters.dateWindowDays === "7" || filters.dateWindowDays === "30" || filters.dateWindowDays === "90" || filters.dateWindowDays === "365") {
      input.dateWindowDays = Number(filters.dateWindowDays) as 7 | 30 | 90 | 365;
    }
    if (debouncedQuery.length > 0) input.query = debouncedQuery;

    return input;
  }, [debouncedQuery, filters]);

  const hasActiveFilters = Object.keys(snapshotFilters).length > 0;
  const auditTrailFilters = useMemo(
    () => ({
      tenantId: filters.tenantId !== "all" ? filters.tenantId : undefined,
      caseId: filters.caseId !== "all" ? filters.caseId : undefined,
      limit: 30,
    }),
    [filters.caseId, filters.tenantId],
  );

  const baseSnapshotQuery = trpc.dashboard.ceoSnapshot.useQuery(undefined, {
    enabled: isAdmin,
    retry: false,
    refetchOnWindowFocus: false,
  });

  const filteredSnapshotQuery = trpc.dashboard.ceoSnapshot.useQuery(snapshotFilters, {
    enabled: isAdmin && hasActiveFilters,
    retry: false,
    refetchOnWindowFocus: false,
  });
  const auditTrailQuery = trpc.audit.list.useQuery(auditTrailFilters, {
    enabled: isAdmin,
    retry: false,
    refetchOnWindowFocus: false,
  });
  const snapshotData = hasActiveFilters ? filteredSnapshotQuery.data : baseSnapshotQuery.data;
  const isMasterUser = snapshotData?.viewerCapabilities?.isMasterUser ?? baseSnapshotQuery.data?.viewerCapabilities?.isMasterUser ?? false;
  const masterMetricsQuery = trpc.dashboard.ceoMasterMetrics.useQuery(undefined, {
    enabled: isAdmin && isMasterUser,
    retry: false,
    refetchOnWindowFocus: false,
  });
  const recordConsoleViewMutation = trpc.dashboard.ceoRecordConsoleView.useMutation();
  const recordGuardrailMutation = trpc.dashboard.ceoRecordGuardrailEvent.useMutation();
  const recordExportAuditMutation = trpc.dashboard.ceoRecordExportAudit.useMutation();

  const snapshotError = hasActiveFilters ? filteredSnapshotQuery.error : baseSnapshotQuery.error;
  const isInitialLoading = !baseSnapshotQuery.data && baseSnapshotQuery.isLoading;
  const isFilterLoading = hasActiveFilters && !filteredSnapshotQuery.data && filteredSnapshotQuery.isLoading;
  const isRefreshing = baseSnapshotQuery.isFetching || filteredSnapshotQuery.isFetching;
  const snapshotGeneratedAtMs = useMemo(() => {
    if (!snapshotData?.generatedAt) return null;
    const value = new Date(snapshotData.generatedAt).getTime();
    return Number.isNaN(value) ? null : value;
  }, [snapshotData?.generatedAt]);
  const snapshotAgeMs = snapshotGeneratedAtMs === null ? null : Math.max(0, snapshotPulseAt - snapshotGeneratedAtMs);
  const snapshotGeneratedAtIso = useMemo(
    () => (snapshotGeneratedAtMs === null ? null : new Date(snapshotGeneratedAtMs).toISOString()),
    [snapshotGeneratedAtMs],
  );
  const snapshotFreshnessLabel =
    snapshotAgeMs === null ? "Frescura no disponible" : snapshotAgeMs < 60000 ? "Vista fresca" : `Actualizada hace ${Math.max(1, Math.round(snapshotAgeMs / 60000))} min`;
  const isSnapshotStale = snapshotAgeMs !== null && snapshotAgeMs > 2 * 60 * 1000;
  const executiveActionsBlocked = isRefreshing || isSnapshotStale || Boolean(snapshotError);
  const executiveGuardrailDescription = isRefreshing
    ? "La consola está refrescando la vista ejecutiva. Espera a que termine antes de operar cambios sensibles."
    : snapshotError
      ? "La vista ejecutiva tuvo un problema al cargar. Refresca antes de volver a intentar una acción sensible."
      : isSnapshotStale
        ? "Datos desactualizados. Actualiza el dashboard antes de continuar."
        : "La vista visible sigue dentro de la ventana de frescura operativa para ejecutar acciones seguras.";
  const exportGuardReason = getCeoExportBlockReason({
    hasSnapshot: Boolean(snapshotData),
    isRefreshing,
    isSnapshotStale,
    hasSnapshotError: Boolean(snapshotError),
  });
  const currentSectionExportGuardReason =
    currentSection === "bridge" ? "La exportación del panel bridge quedará disponible en una siguiente iteración." : exportGuardReason;

  const alertMutation = trpc.dashboard.ceoUpdateAlertStatus.useMutation();
  const membershipMutation = trpc.dashboard.ceoUpdateMembershipStatus.useMutation();
  const caseMutation = trpc.dashboard.ceoProgressCaseStage.useMutation();

  const globalSummary = baseSnapshotQuery.data?.summary;
  const auditTrail = auditTrailQuery.data ?? [];
  const auditSummary = useMemo(() => buildAuditMonitoringSummary(auditTrail), [auditTrail]);
  const filteredAuditTrail = useMemo(
    () => filterAuditFeed(auditTrail, { family: auditFamilyFilter, severity: auditSeverityFilter }),
    [auditFamilyFilter, auditSeverityFilter, auditTrail],
  );
  const recentOperationalEvents = useMemo(() => filteredAuditTrail.slice(0, 6), [filteredAuditTrail]);
  const latestGuardrailEvent = useMemo(
    () => auditTrail.find((item) => item.action === "document.guardrail_rejected") ?? null,
    [auditTrail],
  );
  const auditExecutiveAlerts = useMemo(() => buildAuditExecutiveAlerts(auditTrail).slice(0, 4), [auditTrail]);
  const bridgeOverview = useMemo(
    () =>
      buildBridgeMonitoringPanel({
        auditTrail,
        tenantHealth: snapshotData?.tenantHealth ?? [],
        recentDocuments: snapshotData?.recentDocuments ?? [],
        recentAlerts: snapshotData?.recentAlerts ?? [],
      }),
    [auditTrail, snapshotData?.recentAlerts, snapshotData?.recentDocuments, snapshotData?.tenantHealth],
  );

  const navigation = useMemo<DashboardNavigationItem[]>(
    () => [
      {
        icon: LayoutDashboard,
        label: "Resumen CEO",
        path: "/ceo",
        badge: globalSummary ? formatNumber(globalSummary.activeCases) : undefined,
      },
      {
        icon: GitBranch,
        label: "Bridge",
        path: "/ceo/bridge",
        badge:
          bridgeOverview.summary.critical + bridgeOverview.summary.warning + bridgeOverview.summary.pending > 0
            ? formatNumber(bridgeOverview.summary.critical + bridgeOverview.summary.warning + bridgeOverview.summary.pending)
            : undefined,
      },
      {
        icon: Siren,
        label: "Alertas",
        path: "/ceo/alertas",
        badge: globalSummary ? formatNumber(globalSummary.openAlerts) : undefined,
      },
      {
        icon: UsersRound,
        label: "Accesos",
        path: "/ceo/accesos",
        badge: globalSummary ? formatNumber(globalSummary.activeMemberships) : undefined,
      },
      {
        icon: Files,
        label: "Documentos",
        path: "/ceo/documentos",
        badge: globalSummary ? formatNumber(globalSummary.pendingDocuments) : undefined,
      },
    ],
    [bridgeOverview.summary.critical, bridgeOverview.summary.pending, bridgeOverview.summary.warning, globalSummary],
  );

  const tenantOptions = useMemo(() => {
    const items = new Map<string, string>();
    for (const tenant of baseSnapshotQuery.data?.tenantHealth ?? []) items.set(tenant.tenantId, tenant.tenantName);
    for (const item of baseSnapshotQuery.data?.recentCases ?? []) items.set(item.tenantId, item.tenantName);
    for (const item of baseSnapshotQuery.data?.recentAlerts ?? []) items.set(item.tenantId, item.tenantName);
    for (const item of baseSnapshotQuery.data?.recentMemberships ?? []) items.set(item.tenantId, item.tenantName);
    for (const item of baseSnapshotQuery.data?.recentDocuments ?? []) items.set(item.tenantId, item.tenantName);
    return Array.from(items.entries())
      .map(([value, label]) => ({ value, label }))
      .sort((a, b) => a.label.localeCompare(b.label, "es-MX"));
  }, [baseSnapshotQuery.data]);

  const severityOptions = useMemo(() => {
    const values = new Set<string>();
    for (const item of baseSnapshotQuery.data?.alertsBySeverity ?? []) values.add(item.severity);
    for (const item of baseSnapshotQuery.data?.recentAlerts ?? []) values.add(item.severity);
    return Array.from(values)
      .map((value) => ({ value, label: value }))
      .sort((a, b) => a.label.localeCompare(b.label, "es-MX"));
  }, [baseSnapshotQuery.data]);

  const caseOptions = useMemo(() => {
    const items = new Map<string, string>();
    for (const item of baseSnapshotQuery.data?.recentCases ?? []) items.set(item.caseId, `${item.title} · ${item.caseId}`);
    for (const item of baseSnapshotQuery.data?.recentAlerts ?? []) {
      if (item.caseId) items.set(item.caseId, `${item.caseTitle || item.caseId} · ${item.caseId}`);
    }
    for (const item of baseSnapshotQuery.data?.recentMemberships ?? []) {
      if (item.caseId) items.set(item.caseId, `${item.caseTitle || item.caseId} · ${item.caseId}`);
    }
    for (const item of baseSnapshotQuery.data?.recentDocuments ?? []) items.set(item.caseId, `${item.caseTitle || item.caseId} · ${item.caseId}`);
    return Array.from(items.entries())
      .map(([value, label]) => ({ value, label }))
      .sort((a, b) => a.label.localeCompare(b.label, "es-MX"));
  }, [baseSnapshotQuery.data]);

  const userOptions = useMemo(() => {
    const items = new Map<string, string>();
    for (const item of baseSnapshotQuery.data?.recentMemberships ?? []) {
      items.set(String(item.userId), item.userName || item.userEmail || `Usuario ${item.userId}`);
    }
    return Array.from(items.entries())
      .map(([value, label]) => ({ value, label }))
      .sort((a, b) => a.label.localeCompare(b.label, "es-MX"));
  }, [baseSnapshotQuery.data]);

  const filteredCounts = useMemo(
    () => ({
      tenants: snapshotData?.tenantHealth.length ?? 0,
      cases: snapshotData?.recentCases.length ?? 0,
      alerts: snapshotData?.recentAlerts.length ?? 0,
      memberships: snapshotData?.recentMemberships.length ?? 0,
      documents: snapshotData?.recentDocuments.length ?? 0,
    }),
    [snapshotData],
  );

  const currentSectionCount = useMemo(
    () => (currentSection === "bridge" ? bridgeOverview.rows.length : getCurrentSectionCount(currentSection, snapshotData)),
    [bridgeOverview.rows.length, currentSection, snapshotData],
  );
  const exportableSection = currentSection === "bridge" ? "resumen" : currentSection;
  const lastTrackedSectionViewRef = useRef<string | null>(null);
  const lastTrackedMasterMetricsRef = useRef<string | null>(null);

  useEffect(() => {
    if (!isAdmin) return;

    const nextViewKey = `${currentSection}:${snapshotGeneratedAtIso ?? "pending"}:${hasActiveFilters ? "filtered" : "global"}`;
    if (lastTrackedSectionViewRef.current === nextViewKey) {
      return;
    }

    lastTrackedSectionViewRef.current = nextViewKey;
    trackCeoConsoleViewed(currentSection, {
      source: "ceo_dashboard",
      hasActiveFilters,
      visibleCount: currentSectionCount,
    });
    void recordConsoleViewMutation
      .mutateAsync({
        tenantId: filters.tenantId !== "all" ? filters.tenantId : undefined,
        section: currentSection,
        snapshotGeneratedAt: snapshotGeneratedAtIso ?? undefined,
        hasActiveFilters,
        visibleCount: currentSectionCount,
      })
      .catch((error) => {
        console.warn("No se pudo registrar la vista persistente del dashboard CEO", error);
      });
  }, [currentSection, currentSectionCount, filters.tenantId, hasActiveFilters, isAdmin, recordConsoleViewMutation, snapshotGeneratedAtIso]);

  useEffect(() => {
    if (!isMasterUser || !masterMetricsQuery.data) return;

    const nextMetricsKey = `${masterMetricsQuery.data.generatedAt}`;
    if (lastTrackedMasterMetricsRef.current === nextMetricsKey) {
      return;
    }

    lastTrackedMasterMetricsRef.current = nextMetricsKey;
    trackCeoMasterMetricsViewed({
      source: "ceo_dashboard",
      totalConsoleViews: masterMetricsQuery.data.summary.totalConsoleViews,
      totalGuardrailBlocks: masterMetricsQuery.data.summary.totalGuardrailBlocks,
      totalExports: masterMetricsQuery.data.summary.totalExports,
    });
  }, [isMasterUser, masterMetricsQuery.data]);

  const safeCaseActions = useMemo(
    () =>
      (snapshotData?.recentCases ?? [])
        .map((item) => ({
          ...item,
          nextStatus: getSafeNextCaseStatus(item.status),
          actionLabel: getSafeCaseActionLabel(item.status),
        }))
        .filter(
          (item): item is typeof item & { nextStatus: "analysis" | "conciliation" | "litigation"; actionLabel: string } =>
            Boolean(item.nextStatus && item.actionLabel),
        )
        .slice(0, 3),
    [snapshotData?.recentCases],
  );

  const safeAlertActions = useMemo(
    () =>
      (snapshotData?.recentAlerts ?? [])
        .map((alert) => ({
          ...alert,
          nextStatus: getSafeNextAlertStatus(alert.status),
          actionLabel: getSafeAlertActionLabel(alert.status),
        }))
        .filter(
          (alert): alert is typeof alert & { nextStatus: "acknowledged" | "resolved"; actionLabel: string } =>
            Boolean(alert.nextStatus && alert.actionLabel),
        )
        .slice(0, 3),
    [snapshotData?.recentAlerts],
  );

  const safeMembershipActions = useMemo(
    () =>
      (snapshotData?.recentMemberships ?? [])
        .map((membership) => ({
          ...membership,
          action: getSafeMembershipAction(membership),
        }))
        .filter(
          (membership): membership is typeof membership & { action: { status: "active" | "revoked"; label: string } } =>
            Boolean(membership.action),
        )
        .slice(0, 3),
    [snapshotData?.recentMemberships],
  );

  const activeFilterChips = useMemo(() => {
    const chips: Array<{ key: keyof FilterState | "query"; label: string }> = [];

    if (debouncedQuery.length > 0) chips.push({ key: "query", label: `Búsqueda: ${debouncedQuery}` });
    if (filters.tenantId !== "all") {
      const tenantLabel = tenantOptions.find((item) => item.value === filters.tenantId)?.label ?? filters.tenantId;
      chips.push({ key: "tenantId", label: `Tenant: ${tenantLabel}` });
    }
    if (filters.severity !== "all") chips.push({ key: "severity", label: `Severidad: ${filters.severity}` });
    if (filters.caseId !== "all") {
      const caseLabel = caseOptions.find((item) => item.value === filters.caseId)?.label ?? filters.caseId;
      chips.push({ key: "caseId", label: `Caso: ${caseLabel}` });
    }
    if (filters.userId !== "all") {
      const userLabel = userOptions.find((item) => item.value === filters.userId)?.label ?? filters.userId;
      chips.push({ key: "userId", label: `Usuario: ${userLabel}` });
    }
    if (filters.dateWindowDays !== "all") {
      const dateLabel = DATE_WINDOW_OPTIONS.find((item) => item.value === filters.dateWindowDays)?.label ?? `${filters.dateWindowDays} días`;
      chips.push({ key: "dateWindowDays", label: `Fecha: ${dateLabel}` });
    }

    return chips;
  }, [caseOptions, debouncedQuery, filters, tenantOptions, userOptions]);

  const removeFilterChip = (key: keyof FilterState | "query") => {
    if (key === "query") {
      setQueryDraft("");
      setDebouncedQuery("");
      return;
    }

    setFilters((previous) => ({
      ...previous,
      [key]: "all",
    }));
  };

  const clearAllFilters = () => {
    setFilters(DEFAULT_FILTER_STATE);
    setQueryDraft("");
    setDebouncedQuery("");
  };

  const clearAuditFeedFilters = () => {
    setAuditFamilyFilter("all");
    setAuditSeverityFilter("all");
  };

  const focusAuditItem = (item: AuditFeedItem) => {
    const descriptor = getAuditDrilldownDescriptor(item);
    setFilters((previous) => ({
      ...previous,
      tenantId: item.tenantId,
      caseId: item.caseId ?? "all",
    }));
    setLocation(descriptor.path);
  };

  const focusExecutiveAlert = (alert: AuditExecutiveAlert) => {
    setFilters((previous) => ({
      ...previous,
      tenantId: alert.tenantId,
      caseId: alert.caseId ?? "all",
    }));
    setAuditFamilyFilter("guardrail");
    setAuditSeverityFilter(alert.severity === "normal" ? "all" : alert.severity);
    setLocation("/ceo");
  };

  const isAlertBusy = (alertId: number) => alertMutation.isPending && alertMutation.variables?.alertId === alertId;
  const isMembershipBusy = (membershipId: number) =>
    membershipMutation.isPending && membershipMutation.variables?.membershipId === membershipId;
  const isCaseBusy = (tenantId: string, caseId: string) =>
    caseMutation.isPending && caseMutation.variables?.tenantId === tenantId && caseMutation.variables?.caseId === caseId;
  const isConfirmingExecutiveAction = alertMutation.isPending || membershipMutation.isPending || caseMutation.isPending;

  function notifyExecutiveGuardrail(actionKind: "alert" | "membership" | "case" | "export" | "refresh" | "master_metrics") {
    const reason = isRefreshing ? "snapshot_refreshing" : snapshotError ? "snapshot_error" : isSnapshotStale ? "snapshot_stale" : "guardrail_active";

    trackCeoGuardrail("blocked", {
      source: "ceo_dashboard",
      section: currentSection,
      actionKind,
      reason,
      hasActiveFilters,
      visibleCount: currentSectionCount,
    });

    void recordGuardrailMutation
      .mutateAsync({
        tenantId: filters.tenantId !== "all" ? filters.tenantId : undefined,
        section: currentSection,
        actionKind,
        reason,
        description: executiveGuardrailDescription,
        snapshotGeneratedAt: snapshotGeneratedAtIso ?? undefined,
        hasActiveFilters,
        visibleCount: currentSectionCount,
      })
      .catch((error) => {
        console.warn("No se pudo registrar el bloqueo persistente del guardrail CEO", error);
      });

    sonnerToast.error("Actualiza la vista antes de operar", {
      description: executiveGuardrailDescription,
    });
  }

  async function refreshSnapshotWithSuccess(title: string, description: string) {
    await utils.dashboard.ceoSnapshot.invalidate();
    sonnerToast.success(title, { description });
  }

  async function handleRefresh() {
    trackCeoRefresh(currentSection, {
      source: "ceo_dashboard",
      hasActiveFilters,
      visibleCount: currentSectionCount,
    });
    await utils.dashboard.ceoSnapshot.invalidate();
  }

  function requestAlertAction(alertId: number, title: string, status: string) {
    if (executiveActionsBlocked) {
      notifyExecutiveGuardrail("alert");
      return;
    }

    const nextStatus = getSafeNextAlertStatus(status);
    const actionLabel = getSafeAlertActionLabel(status);
    if (!nextStatus || !actionLabel) return;
    if (status !== "open" && status !== "acknowledged" && status !== "resolved") return;

    setPendingExecutiveAction({
      kind: "alert",
      alertId,
      title,
      currentStatus: status,
      nextStatus,
      actionLabel,
    });
  }

  function requestMembershipAction(
    membershipId: number,
    membership: { status: string; accessScope: string; caseId?: string | null },
    userLabel: string,
  ) {
    if (executiveActionsBlocked) {
      notifyExecutiveGuardrail("membership");
      return;
    }

    const action = getSafeMembershipAction(membership);
    if (!action) return;
    if (membership.status !== "active" && membership.status !== "revoked") return;

    setPendingExecutiveAction({
      kind: "membership",
      membershipId,
      userLabel,
      currentStatus: membership.status,
      nextStatus: action.status,
      actionLabel: action.label,
    });
  }

  function requestCaseAction(tenantId: string, caseId: string, title: string, status: string) {
    if (executiveActionsBlocked) {
      notifyExecutiveGuardrail("case");
      return;
    }

    const nextStatus = getSafeNextCaseStatus(status);
    const actionLabel = getSafeCaseActionLabel(status);
    if (!nextStatus || !actionLabel) return;
    if (status !== "intake" && status !== "analysis" && status !== "conciliation" && status !== "litigation" && status !== "archived") return;

    setPendingExecutiveAction({
      kind: "case",
      tenantId,
      caseId,
      title,
      currentStatus: status,
      nextStatus,
      actionLabel,
    });
  }

  async function executePendingExecutiveAction(action: PendingExecutiveAction) {
    if (executiveActionsBlocked || !snapshotGeneratedAtIso) {
      notifyExecutiveGuardrail(action.kind);
      setPendingExecutiveAction(null);
      return;
    }

    try {
      if (action.kind === "alert") {
        await alertMutation.mutateAsync({
          alertId: action.alertId,
          status: action.nextStatus,
          expectedCurrentStatus: action.currentStatus,
          snapshotGeneratedAt: snapshotGeneratedAtIso!,
        });
        await refreshSnapshotWithSuccess("Alerta actualizada", `${action.title}: ${action.actionLabel.toLowerCase()} y traza registrada.`);
        return;
      }

      if (action.kind === "membership") {
        await membershipMutation.mutateAsync({
          membershipId: action.membershipId,
          status: action.nextStatus,
          expectedCurrentStatus: action.currentStatus,
          snapshotGeneratedAt: snapshotGeneratedAtIso!,
        });
        await refreshSnapshotWithSuccess("Acceso actualizado", `${action.userLabel}: ${action.actionLabel.toLowerCase()} con trazabilidad ejecutiva.`);
        return;
      }

      await caseMutation.mutateAsync({
        tenantId: action.tenantId,
        caseId: action.caseId,
        status: action.nextStatus,
        expectedCurrentStatus: action.currentStatus,
        snapshotGeneratedAt: snapshotGeneratedAtIso,
      });
      await refreshSnapshotWithSuccess("Caso actualizado", `${action.title}: ${action.actionLabel.toLowerCase()} y bitácora registrada.`);
    } catch (error) {
      const title = action.kind === "case" ? "No fue posible confirmar el avance del caso" : action.kind === "membership" ? "No fue posible actualizar el acceso" : "No fue posible actualizar la alerta";
      sonnerToast.error(title, {
        description: getSafeActionErrorMessage(error),
      });
    } finally {
      setPendingExecutiveAction(null);
    }
  }

  async function handleExport(kind: "csv" | "pdf") {
    if (currentSectionExportGuardReason || !snapshotData) {
      trackCeoExport(kind, "blocked", {
        section: exportableSection,
        source: "ceo_dashboard",
        hasActiveFilters,
        visibleCount: currentSectionCount,
        reason: currentSectionExportGuardReason ?? "snapshot_not_ready",
      });
      sonnerToast.error("La exportación ejecutiva está bloqueada", {
        description:
          currentSectionExportGuardReason ?? "Espera a que el snapshot ejecutivo termine de cargar para generar el reporte.",
      });
      return;
    }

    const actorLabel = user?.name || user?.email || "Operación ejecutiva";
    const appliedFilters = activeFilterChips.map((chip) => chip.label);

    trackCeoExport(kind, "requested", {
      section: exportableSection,
      source: "ceo_dashboard",
      hasActiveFilters,
      visibleCount: currentSectionCount,
    });

    try {
      setExportKind(kind);
      const filename =
        kind === "pdf"
          ? downloadCeoPdfReport({
              section: exportableSection,
              snapshot: snapshotData,
              appliedFilters,
              actorLabel,
            })
          : downloadCeoCsvReport({
              section: exportableSection,
              snapshot: snapshotData,
              appliedFilters,
              actorLabel,
            });

      try {
        await recordExportAuditMutation.mutateAsync({
          tenantId: filters.tenantId !== "all" ? filters.tenantId : undefined,
          section: exportableSection,
          format: kind,
          snapshotGeneratedAt: snapshotGeneratedAtIso ?? new Date().toISOString(),
          appliedFilters,
          visibleCount: currentSectionCount,
        });
      } catch (auditError) {
        console.warn("No se pudo registrar la auditoría del export ejecutivo", auditError);
        sonnerToast.warning("El reporte se descargó, pero la trazabilidad del export no quedó registrada.");
      }

      trackCeoExport(kind, "completed", {
        section: exportableSection,
        source: "ceo_dashboard",
        hasActiveFilters,
        visibleCount: currentSectionCount,
      });
      sonnerToast.success(kind === "pdf" ? "Reporte PDF generado" : "Reporte CSV generado", {
        description: `Archivo descargado: ${filename}`,
      });
    } catch (error) {
      trackCeoExport(kind, "failed", {
        section: exportableSection,
        source: "ceo_dashboard",
        hasActiveFilters,
        visibleCount: currentSectionCount,
        reason: error instanceof Error ? error.message : "unexpected_error",
      });
      sonnerToast.error(kind === "pdf" ? "No fue posible generar el PDF" : "No fue posible generar el CSV", {
        description: error instanceof Error ? error.message : "Intenta nuevamente en unos segundos.",
      });
    } finally {
      setExportKind(null);
    }
  }

  if (loading || isViewingAsUser) {
    return null;
  }


  return (
    <DashboardLayout
      title="Dashboard CEO"
      subtitle="Centro de mando ejecutivo para AuditaPatron"
      navigation={navigation}
      headerActions={
        <>
          <Button
            variant="outline"
            className="rounded-full bg-white"
            title={currentSectionExportGuardReason ?? undefined}
            disabled={Boolean(currentSectionExportGuardReason) || exportKind !== null}
            onClick={() => {
              void handleExport("csv");
            }}
          >
            {exportKind === "csv" ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Files className="mr-2 h-4 w-4" />}
            Exportar CSV
          </Button>
          <Button
            variant="outline"
            className="rounded-full bg-white"
            title={currentSectionExportGuardReason ?? undefined}
            disabled={Boolean(currentSectionExportGuardReason) || exportKind !== null}
            onClick={() => {
              void handleExport("pdf");
            }}
          >
            {exportKind === "pdf" ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ShieldCheck className="mr-2 h-4 w-4" />}
            Reporte PDF
          </Button>
          <Button variant="outline" className="rounded-full" onClick={() => void handleRefresh()}>
            <RefreshCw className={`mr-2 h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
            Actualizar
          </Button>
          <Button variant="ghost" className="rounded-full" onClick={() => setLocation("/")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Sitio público
          </Button>
        </>
      }
    >
      {!isAdmin ? (
        <section className="rounded-[2rem] border border-amber-200 bg-amber-50/90 p-8 shadow-[0_24px_70px_-34px_rgba(146,64,14,0.18)]">
          <div className="flex flex-wrap items-start gap-4">
            <div className="rounded-2xl bg-white p-3 text-amber-700 shadow-sm">
              <ShieldX className="h-6 w-6" />
            </div>
            <div className="max-w-3xl space-y-3">
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-amber-700">Acceso restringido</p>
              <h2 className="text-2xl font-semibold tracking-tight text-slate-950">
                Esta consola ejecutiva sólo está disponible para perfiles administradores.
              </h2>
              <p className="text-base leading-7 text-slate-700">
                Tu sesión está autenticada, pero no tiene permisos para visualizar el tablero global del CEO. Si este
                acceso debe habilitarse, actualiza el rol del usuario a <strong>admin</strong> desde la administración
                interna.
              </p>
            </div>
          </div>
        </section>
      ) : isInitialLoading || isFilterLoading ? (
        <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 8 }).map((_, index) => (
            <div key={index} className="h-32 animate-pulse rounded-3xl border border-white/60 bg-white/75" />
          ))}
        </section>
      ) : snapshotError || !snapshotData || !globalSummary ? (
        <section className="rounded-[2rem] border border-rose-200 bg-rose-50/90 p-8 shadow-[0_24px_70px_-34px_rgba(159,18,57,0.2)]">
          <div className="flex flex-wrap items-start gap-4">
            <div className="rounded-2xl bg-white p-3 text-rose-700 shadow-sm">
              <AlertTriangle className="h-6 w-6" />
            </div>
            <div className="max-w-3xl space-y-3">
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-rose-700">Lectura no disponible</p>
              <h2 className="text-2xl font-semibold tracking-tight text-slate-950">
                No fue posible cargar el snapshot ejecutivo del CEO.
              </h2>
              <p className="text-base leading-7 text-slate-700">
                {snapshotError?.message ?? "Se produjo un error inesperado al consultar el backend ejecutivo."}
              </p>
            </div>
          </div>
        </section>
      ) : (
        <div className="space-y-6">
          <section className="rounded-[2rem] border border-white/70 bg-[linear-gradient(135deg,rgba(15,23,42,0.98),rgba(15,118,110,0.9))] p-6 text-white shadow-[0_34px_90px_-42px_rgba(15,23,42,0.56)]">
            <div className="flex flex-wrap items-start justify-between gap-5">
              <div className="max-w-3xl space-y-3">
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-teal-100/85">Consola ejecutiva</p>
                <h2 className="text-3xl font-semibold tracking-tight">Visibilidad integral para operar AuditaPatron sin fricción.</h2>
                <p className="max-w-2xl text-sm leading-7 text-slate-100/90">
                  Este tablero concentra salud operativa, alertas, accesos por caso y trazabilidad documental en una sola
                  superficie para tomar decisiones rápidas con contexto y control.
                </p>
              </div>
              <div className="min-w-[240px] rounded-[1.5rem] border border-white/15 bg-white/10 p-4 backdrop-blur">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-teal-100/80">Última actualización</p>
                <p className="mt-2 text-lg font-semibold">{formatDateTime(snapshotData.generatedAt)}</p>
                <p className="mt-2 text-sm leading-6 text-slate-100/80">
                  Usuario actual: <strong>{user?.name || user?.email || "Administrador"}</strong>
                </p>
                <p className="mt-2 text-xs leading-5 text-slate-200/80">
                  Vista actual: <strong>{getSectionLabel(currentSection)}</strong>
                  {hasActiveFilters ? ` · ${formatNumber(currentSectionCount)} coincidencias visibles` : " · sin filtros activos"}
                </p>
              </div>
            </div>
          </section>

          <section className="rounded-[1.8rem] border border-white/70 bg-white/92 p-5 shadow-[0_24px_70px_-34px_rgba(15,23,42,0.18)]">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="max-w-3xl space-y-2">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Exploración ejecutiva</p>
                <h3 className="text-xl font-semibold tracking-tight text-slate-950">Filtros y búsqueda rápida transversal</h3>
                <p className="text-sm leading-6 text-slate-600">
                  Busca tenants, casos, alertas, accesos y documentos desde una sola superficie. Los KPIs superiores se
                  mantienen globales para conservar contexto; los listados y paneles inferiores sí reaccionan a los filtros.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Badge className="rounded-full border border-slate-200 bg-slate-100 text-slate-700">
                  {hasActiveFilters ? `${formatNumber(currentSectionCount)} resultados visibles` : "Vista global"}
                </Badge>
                <Button
                  variant="outline"
                  className="rounded-full bg-white"
                  onClick={() => setShowAdvancedFilters((previous) => !previous)}
                >
                  <Filter className="mr-2 h-4 w-4" />
                  {showAdvancedFilters ? "Ocultar filtros avanzados" : "Más filtros"}
                </Button>
              </div>
            </div>

            <div className="mt-5 grid gap-4 xl:grid-cols-[minmax(0,1.6fr)_repeat(3,minmax(0,1fr))]">
              <label className="block space-y-2 xl:col-span-1">
                <span className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Búsqueda única</span>
                <div className="flex items-center gap-2 rounded-[1.2rem] border border-slate-200 bg-white px-4 py-3 shadow-sm">
                  <Search className="h-4 w-4 text-slate-400" />
                  <input
                    value={queryDraft}
                    onChange={(event) => setQueryDraft(event.target.value)}
                    placeholder="Buscar tenant, caso, alerta, acceso o documento"
                    className="w-full border-0 bg-transparent text-sm text-slate-950 outline-none placeholder:text-slate-400"
                  />
                  {queryDraft.length > 0 ? (
                    <button
                      type="button"
                      className="rounded-full p-1 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
                      onClick={() => {
                        setQueryDraft("");
                        setDebouncedQuery("");
                      }}
                    >
                      <X className="h-4 w-4" />
                    </button>
                  ) : null}
                </div>
              </label>

              <label className="block space-y-2">
                <span className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Tenant</span>
                <select
                  value={filters.tenantId}
                  onChange={(event) => setFilters((previous) => ({ ...previous, tenantId: event.target.value }))}
                  className="h-12 w-full rounded-[1.2rem] border border-slate-200 bg-white px-4 text-sm text-slate-950 shadow-sm outline-none transition focus:border-teal-400"
                >
                  <option value="all">Todos los tenants</option>
                  {tenantOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </label>

              <label className="block space-y-2">
                <span className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Severidad</span>
                <select
                  value={filters.severity}
                  onChange={(event) => setFilters((previous) => ({ ...previous, severity: event.target.value }))}
                  className="h-12 w-full rounded-[1.2rem] border border-slate-200 bg-white px-4 text-sm text-slate-950 shadow-sm outline-none transition focus:border-teal-400"
                >
                  <option value="all">Todas las severidades</option>
                  {severityOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </label>

              <label className="block space-y-2">
                <span className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Ventana temporal</span>
                <select
                  value={filters.dateWindowDays}
                  onChange={(event) => setFilters((previous) => ({ ...previous, dateWindowDays: event.target.value }))}
                  className="h-12 w-full rounded-[1.2rem] border border-slate-200 bg-white px-4 text-sm text-slate-950 shadow-sm outline-none transition focus:border-teal-400"
                >
                  <option value="all">Todo el histórico visible</option>
                  {DATE_WINDOW_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            {showAdvancedFilters ? (
              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <label className="block space-y-2">
                  <span className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Caso</span>
                  <select
                    value={filters.caseId}
                    onChange={(event) => setFilters((previous) => ({ ...previous, caseId: event.target.value }))}
                    className="h-12 w-full rounded-[1.2rem] border border-slate-200 bg-white px-4 text-sm text-slate-950 shadow-sm outline-none transition focus:border-teal-400"
                  >
                    <option value="all">Todos los casos</option>
                    {caseOptions.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </label>

                <label className="block space-y-2">
                  <span className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Usuario</span>
                  <select
                    value={filters.userId}
                    onChange={(event) => setFilters((previous) => ({ ...previous, userId: event.target.value }))}
                    className="h-12 w-full rounded-[1.2rem] border border-slate-200 bg-white px-4 text-sm text-slate-950 shadow-sm outline-none transition focus:border-teal-400"
                  >
                    <option value="all">Todos los usuarios</option>
                    {userOptions.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
            ) : null}

            <div className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-[1.2rem] border border-slate-200 bg-slate-50/80 px-4 py-3">
              <div className="flex flex-wrap items-center gap-2 text-sm text-slate-600">
                <span className="font-medium text-slate-950">Cobertura del filtro actual:</span>
                <Badge className="rounded-full border border-white bg-white text-slate-700">Tenants {formatNumber(filteredCounts.tenants)}</Badge>
                <Badge className="rounded-full border border-white bg-white text-slate-700">Casos {formatNumber(filteredCounts.cases)}</Badge>
                <Badge className="rounded-full border border-white bg-white text-slate-700">Alertas {formatNumber(filteredCounts.alerts)}</Badge>
                <Badge className="rounded-full border border-white bg-white text-slate-700">Accesos {formatNumber(filteredCounts.memberships)}</Badge>
                <Badge className="rounded-full border border-white bg-white text-slate-700">Docs {formatNumber(filteredCounts.documents)}</Badge>
              </div>
              {hasActiveFilters ? (
                <Button variant="ghost" className="rounded-full text-slate-700" onClick={clearAllFilters}>
                  <X className="mr-2 h-4 w-4" />
                  Limpiar filtros
                </Button>
              ) : null}
            </div>

            {activeFilterChips.length > 0 ? (
              <div className="mt-4 flex flex-wrap gap-2">
                {activeFilterChips.map((chip) => (
                  <button
                    key={`${chip.key}-${chip.label}`}
                    type="button"
                    className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 shadow-sm transition hover:border-slate-300 hover:text-slate-950"
                    onClick={() => removeFilterChip(chip.key)}
                  >
                    <span>{chip.label}</span>
                    <X className="h-3.5 w-3.5" />
                  </button>
                ))}
              </div>
            ) : null}
          </section>

          <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
            <KpiCard label="Tenants activos" value={globalSummary.totalTenants} helper="Organizaciones con operación visible" />
            <KpiCard label="Casos activos" value={globalSummary.activeCases} helper="Expedientes en intake, análisis, conciliación o litigio" />
            <KpiCard label="Alertas abiertas" value={globalSummary.openAlerts} helper={`${formatNumber(globalSummary.criticalAlerts)} críticas`} />
            <KpiCard label="Accesos vigentes" value={globalSummary.activeMemberships} helper={`${formatNumber(globalSummary.caseScopedMemberships)} por caso`} />
            <KpiCard label="Documentos pendientes" value={globalSummary.pendingDocuments} helper={`${formatNumber(globalSummary.supersededDocuments)} reemplazados`} />
          </section>

          {isMasterUser ? (
            <section className="rounded-[1.8rem] border border-violet-200/70 bg-[linear-gradient(135deg,rgba(245,243,255,0.98),rgba(238,242,255,0.94))] p-5 shadow-[0_26px_80px_-44px_rgba(76,29,149,0.3)]">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="max-w-3xl space-y-2">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-violet-600">Panel maestro</p>
                  <h3 className="text-xl font-semibold tracking-tight text-slate-950">Métricas exclusivas del usuario dueño</h3>
                  <p className="text-sm leading-6 text-slate-700">
                    Este bloque concentra vistas ejecutivas, exportes y bloqueos de guardrails persistidos en la bitácora para el usuario maestro.
                  </p>
                </div>
                <div className="rounded-[1.2rem] border border-white/70 bg-white/80 px-4 py-3 text-sm text-slate-700 shadow-sm">
                  {masterMetricsQuery.isLoading ? "Cargando métricas maestras…" : `Corte ${formatDateTime(masterMetricsQuery.data?.generatedAt ?? null)}`}
                </div>
              </div>

              {masterMetricsQuery.error ? (
                <div className="mt-4 rounded-[1.2rem] border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">
                  {masterMetricsQuery.error.message}
                </div>
              ) : (
                <>
                  <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                    <KpiCard label="Vistas CEO" value={masterMetricsQuery.data?.summary.totalConsoleViews ?? 0} helper={`Últimos 7 días: ${formatNumber(masterMetricsQuery.data?.last7Days.consoleViews ?? 0)}`} />
                    <KpiCard label="Guardrails bloqueados" value={masterMetricsQuery.data?.summary.totalGuardrailBlocks ?? 0} helper={`Últimos 7 días: ${formatNumber(masterMetricsQuery.data?.last7Days.guardrailBlocks ?? 0)}`} />
                    <KpiCard label="Exportes trazados" value={masterMetricsQuery.data?.summary.totalExports ?? 0} helper={`Últimos 7 días: ${formatNumber(masterMetricsQuery.data?.last7Days.exports ?? 0)}`} />
                    <KpiCard label="Actores únicos" value={masterMetricsQuery.data?.summary.uniqueActors ?? 0} helper="Usuarios administradores con interacción registrada" />
                  </div>
                  <div className="mt-4 grid gap-4 md:grid-cols-3">
                    <div className="rounded-[1.2rem] border border-white/70 bg-white/80 p-4 text-sm text-slate-700 shadow-sm">
                      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Última vista CEO</p>
                      <p className="mt-2 text-base font-semibold text-slate-950">{formatDateTime(masterMetricsQuery.data?.latestActivity.consoleViewedAt ?? null)}</p>
                    </div>
                    <div className="rounded-[1.2rem] border border-white/70 bg-white/80 p-4 text-sm text-slate-700 shadow-sm">
                      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Último bloqueo</p>
                      <p className="mt-2 text-base font-semibold text-slate-950">{formatDateTime(masterMetricsQuery.data?.latestActivity.guardrailBlockedAt ?? null)}</p>
                    </div>
                    <div className="rounded-[1.2rem] border border-white/70 bg-white/80 p-4 text-sm text-slate-700 shadow-sm">
                      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Último export</p>
                      <p className="mt-2 text-base font-semibold text-slate-950">{formatDateTime(masterMetricsQuery.data?.latestActivity.exportGeneratedAt ?? null)}</p>
                    </div>
                  </div>
                </>
              )}
            </section>
          ) : null}

          <div className="rounded-[1.4rem] border border-cyan-100 bg-cyan-50/80 px-4 py-3 text-sm leading-6 text-cyan-950">
            Las tarjetas superiores muestran <strong>contexto global</strong>. Los listados, paneles laterales y contadores de secciones muestran la <strong>vista filtrada</strong> para evitar perder el panorama completo.
          </div>

          <div
            className={`rounded-[1.4rem] border px-4 py-3 text-sm leading-6 ${executiveActionsBlocked ? "border-amber-200 bg-amber-50/90 text-amber-950" : "border-emerald-200 bg-emerald-50/90 text-emerald-950"}`}
          >
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-semibold uppercase tracking-[0.18em]">Frescura operativa</p>
                <p>
                  <strong>{snapshotFreshnessLabel}.</strong> {executiveGuardrailDescription}
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="rounded-full bg-white"
                disabled={isRefreshing}
                onClick={() => {
                  void handleRefresh();
                }}
              >
                {isRefreshing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
                Actualizar vista
              </Button>
            </div>
          </div>

          {currentSection === "resumen" ? (
            <>
              <section className="rounded-[1.8rem] border border-white/70 bg-white/92 p-5 shadow-[0_24px_70px_-34px_rgba(15,23,42,0.18)]">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Bloque seguro</p>
                    <h3 className="mt-1 text-xl font-semibold tracking-tight text-slate-950">Acciones administrativas acotadas</h3>
                  </div>
                  <Badge className="rounded-full border border-emerald-200 bg-emerald-50 text-emerald-700">
                    Sólo cambios con trazabilidad y bajo riesgo
                  </Badge>
                </div>
                <p className="mt-4 text-sm leading-6 text-slate-600">
                  Este bloque sólo expone cambios de bajo riesgo. Cada acción ahora exige una confirmación visual sobre una vista fresca, y el backend rechazará
                  cualquier operación si detecta desalineación de estado o secuencia fuera del carril seguro.
                </p>
                {executiveActionsBlocked ? (
                  <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-950">
                    <strong>Acciones sensibles bloqueadas temporalmente.</strong> {executiveGuardrailDescription}
                  </div>
                ) : null}
                <div className="mt-5 grid gap-4 xl:grid-cols-3">
                  <article className="rounded-[1.4rem] border border-slate-200 bg-slate-50/70 p-4">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="text-base font-semibold text-slate-950">Alertas en secuencia</h4>
                      <Badge className="rounded-full border border-slate-200 bg-white text-slate-700">{formatNumber(safeAlertActions.length)}</Badge>
                    </div>
                    <div className="mt-4 space-y-3">
                      {safeAlertActions.length > 0 ? (
                        safeAlertActions.map((alert) => (
                          <div key={alert.id} className="rounded-2xl bg-white p-3 shadow-sm">
                            <div className="flex flex-wrap items-center gap-2">
                              <Badge className={`rounded-full border ${getSeverityBadgeClass(alert.severity)}`}>{alert.severity}</Badge>
                              <Badge className={`rounded-full border ${getStatusBadgeClass(alert.status)}`}>{alert.status}</Badge>
                            </div>
                            <p className="mt-2 line-clamp-2 text-sm font-semibold text-slate-950">{alert.title}</p>
                            <p className="mt-1 text-xs text-slate-500">{alert.tenantName}</p>
                            <Button
                              className="mt-3 w-full rounded-full"
                              size="sm"
                              disabled={executiveActionsBlocked || isAlertBusy(alert.id)}
                              onClick={() => {
                                requestAlertAction(alert.id, alert.title, alert.status);
                              }}
                            >
                              {isAlertBusy(alert.id) ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                              {alert.actionLabel}
                            </Button>
                          </div>
                        ))
                      ) : (
                        <p className="rounded-2xl bg-white px-4 py-3 text-sm text-slate-600">No hay alertas con transición segura pendiente.</p>
                      )}
                    </div>
                  </article>

                  <article className="rounded-[1.4rem] border border-slate-200 bg-slate-50/70 p-4">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="text-base font-semibold text-slate-950">Accesos por caso</h4>
                      <Badge className="rounded-full border border-slate-200 bg-white text-slate-700">{formatNumber(safeMembershipActions.length)}</Badge>
                    </div>
                    <div className="mt-4 space-y-3">
                      {safeMembershipActions.length > 0 ? (
                        safeMembershipActions.map((membership) => (
                          <div key={membership.id} className="rounded-2xl bg-white p-3 shadow-sm">
                            <div className="flex flex-wrap items-center gap-2">
                              <Badge className={`rounded-full border ${getStatusBadgeClass(membership.status)}`}>{membership.status}</Badge>
                              <Badge className="rounded-full border border-slate-200 bg-white text-slate-700">{membership.role}</Badge>
                            </div>
                            <p className="mt-2 text-sm font-semibold text-slate-950">
                              {membership.userName || membership.userEmail || `Usuario ${membership.userId}`}
                            </p>
                            <p className="mt-1 text-xs text-slate-500">{membership.caseTitle || membership.caseId}</p>
                            <Button
                              variant="outline"
                              className="mt-3 w-full rounded-full bg-white"
                              size="sm"
                              disabled={executiveActionsBlocked || isMembershipBusy(membership.id)}
                              onClick={() => {
                                requestMembershipAction(
                                  membership.id,
                                  membership,
                                  membership.userName || membership.userEmail || `Usuario ${membership.userId}`,
                                );
                              }}
                            >
                              {isMembershipBusy(membership.id) ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                              {membership.action.label}
                            </Button>
                          </div>
                        ))
                      ) : (
                        <p className="rounded-2xl bg-white px-4 py-3 text-sm text-slate-600">No hay accesos por caso aptos para este bloque seguro.</p>
                      )}
                    </div>
                  </article>

                  <article className="rounded-[1.4rem] border border-slate-200 bg-slate-50/70 p-4">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="text-base font-semibold text-slate-950">Avance operativo</h4>
                      <Badge className="rounded-full border border-slate-200 bg-white text-slate-700">{formatNumber(safeCaseActions.length)}</Badge>
                    </div>
                    <div className="mt-4 space-y-3">
                      {safeCaseActions.length > 0 ? (
                        safeCaseActions.map((item) => (
                          <div key={item.caseId} className="rounded-2xl bg-white p-3 shadow-sm">
                            <div className="flex flex-wrap items-center gap-2">
                              <Badge className={`rounded-full border ${getStatusBadgeClass(item.status)}`}>{item.status}</Badge>
                              <Badge className="rounded-full border border-slate-200 bg-white text-slate-700">{item.tenantName}</Badge>
                            </div>
                            <p className="mt-2 line-clamp-2 text-sm font-semibold text-slate-950">{item.title}</p>
                            <p className="mt-1 text-xs text-slate-500">Última actividad: {formatDateTime(item.lastActivityAt ?? item.updatedAt)}</p>
                            <Button
                              variant="outline"
                              className="mt-3 w-full rounded-full bg-white"
                              size="sm"
                              disabled={executiveActionsBlocked || isCaseBusy(item.tenantId, item.caseId)}
                              onClick={() => {
                                requestCaseAction(item.tenantId, item.caseId, item.title, item.status);
                              }}
                            >
                              {isCaseBusy(item.tenantId, item.caseId) ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                              {item.actionLabel}
                            </Button>
                          </div>
                        ))
                      ) : (
                        <p className="rounded-2xl bg-white px-4 py-3 text-sm text-slate-600">No hay casos con siguiente avance operativo seguro disponible.</p>
                      )}
                    </div>
                  </article>
                </div>
              </section>

              <section className="rounded-[1.8rem] border border-white/70 bg-white/92 p-5 shadow-[0_24px_70px_-34px_rgba(15,23,42,0.18)]">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Bitácora operativa</p>
                    <h3 className="mt-1 text-xl font-semibold tracking-tight text-slate-950">Trazabilidad reciente para diagnóstico ejecutivo</h3>
                  </div>
                  <Badge className="rounded-full border border-slate-200 bg-slate-100 text-slate-700">
                    {auditTrailQuery.isFetching ? "Actualizando eventos" : `${formatNumber(auditSummary.totalEvents)} eventos recientes`}
                  </Badge>
                </div>
                <p className="mt-4 max-w-3xl text-sm leading-6 text-slate-600">
                  Esta superficie reutiliza la bitácora de auditoría existente para mostrar actividad reciente, rechazos operativos de guardrails y cobertura de casos visibles sin abrir un frente nuevo de infraestructura.
                </p>
                <div className="mt-5 grid gap-4 lg:grid-cols-4">
                  <article className="rounded-[1.4rem] border border-slate-200 bg-slate-50/70 p-4">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">Eventos visibles</p>
                    <p className="mt-2 text-2xl font-semibold tracking-tight text-slate-950">{formatNumber(auditSummary.totalEvents)}</p>
                    <p className="mt-2 text-sm text-slate-500">Últimos movimientos auditados bajo el filtro actual.</p>
                  </article>
                  <article className="rounded-[1.4rem] border border-amber-200 bg-amber-50/70 p-4">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-amber-700">Guardrails rechazados</p>
                    <p className="mt-2 text-2xl font-semibold tracking-tight text-amber-950">{formatNumber(auditSummary.guardrailRejections)}</p>
                    <p className="mt-2 text-sm text-amber-900/80">
                      {latestGuardrailEvent ? `Último: ${formatDateTime(latestGuardrailEvent.createdAt)}` : "Sin rechazos operativos recientes en la vista actual."}
                    </p>
                  </article>
                  <article className="rounded-[1.4rem] border border-cyan-200 bg-cyan-50/70 p-4">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-cyan-700">Eventos documentales</p>
                    <p className="mt-2 text-2xl font-semibold tracking-tight text-cyan-950">{formatNumber(auditSummary.documentEvents)}</p>
                    <p className="mt-2 text-sm text-cyan-900/80">Incluye carga, confirmación y rechazos operativos del flujo documental.</p>
                  </article>
                  <article className="rounded-[1.4rem] border border-violet-200 bg-violet-50/70 p-4">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-violet-700">Casos con huella</p>
                    <p className="mt-2 text-2xl font-semibold tracking-tight text-violet-950">{formatNumber(auditSummary.distinctCases)}</p>
                    <p className="mt-2 text-sm text-violet-900/80">Casos distintos tocados por los eventos recientes del rastro operativo.</p>
                  </article>
                </div>
                <div className="mt-5 grid gap-4 xl:grid-cols-[1.15fr_0.85fr]">
                  <div className="rounded-[1.4rem] border border-slate-200 bg-slate-50/70 p-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <h4 className="text-base font-semibold text-slate-950">Eventos recientes</h4>
                        <p className="text-sm text-slate-500">Ordenados desde la actividad más reciente del audit trail y segmentables sin salir del tablero.</p>
                      </div>
                      <Badge className="rounded-full border border-white bg-white text-slate-700">
                        {`${formatNumber(recentOperationalEvents.length)} de ${formatNumber(auditTrail.length)} visibles`}
                      </Badge>
                    </div>
                    <div className="mt-4 space-y-4">
                      <div className="rounded-[1.2rem] border border-dashed border-slate-200 bg-white/80 p-4">
                        <div className="flex flex-wrap items-center justify-between gap-3">
                          <div>
                            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Filtros rápidos</p>
                            <p className="mt-1 text-sm text-slate-500">Combina familia de evento y severidad para aislar fricción, accesos o documentos sin tocar el filtro global.</p>
                          </div>
                          {(auditFamilyFilter !== "all" || auditSeverityFilter !== "all") ? (
                            <Button variant="ghost" className="rounded-full text-slate-700" onClick={clearAuditFeedFilters}>
                              <X className="mr-2 h-4 w-4" />
                              Limpiar vista rápida
                            </Button>
                          ) : null}
                        </div>
                        <div className="mt-4 space-y-3">
                          <div className="flex flex-wrap gap-2">
                            {AUDIT_FAMILY_FILTER_OPTIONS.map((option) => {
                              const active = auditFamilyFilter === option.value;
                              return (
                                <Button
                                  key={option.value}
                                  type="button"
                                  variant="outline"
                                  className={`rounded-full ${active ? "border-slate-900 bg-slate-900 text-white hover:bg-slate-900 hover:text-white" : "bg-white text-slate-700"}`}
                                  onClick={() => setAuditFamilyFilter(option.value)}
                                >
                                  {option.label}
                                </Button>
                              );
                            })}
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {AUDIT_SEVERITY_FILTER_OPTIONS.map((option) => {
                              const active = auditSeverityFilter === option.value;
                              return (
                                <Button
                                  key={option.value}
                                  type="button"
                                  variant="outline"
                                  className={`rounded-full ${active ? "border-slate-900 bg-slate-900 text-white hover:bg-slate-900 hover:text-white" : "bg-white text-slate-700"}`}
                                  onClick={() => setAuditSeverityFilter(option.value)}
                                >
                                  {option.label}
                                </Button>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                      <div className="space-y-3">
                        {recentOperationalEvents.length > 0 ? (
                          recentOperationalEvents.map((item) => {
                            const tone = getAuditActionTone(item.action);
                            const rejectionReason = getAuditRejectionReason(item);
                            const severity = getAuditEventSeverity(item);
                            const drilldown = getAuditDrilldownDescriptor(item);
                            return (
                              <article key={item.id} className={`rounded-[1.2rem] border p-4 ${tone.card}`}>
                                <div className="flex flex-wrap items-center gap-2">
                                  <Badge className={`rounded-full border ${tone.badge}`}>{getAuditActionLabel(item.action)}</Badge>
                                  <Badge className={`rounded-full border ${getSeverityBadgeClass(severity)}`}>{getAuditSeverityLabel(severity)}</Badge>
                                  <Badge className="rounded-full border border-white/80 bg-white/90 text-slate-700">{item.entityType}</Badge>
                                  {item.caseId ? (
                                    <Badge className="rounded-full border border-white/80 bg-white/90 text-slate-700">{item.caseId}</Badge>
                                  ) : null}
                                </div>
                                <p className="mt-3 text-sm font-semibold text-slate-950">{item.tenantId}</p>
                                <p className="mt-1 text-sm text-slate-600">Traza {item.traceId}</p>
                                {item.documentId ? <p className="mt-1 text-sm text-slate-600">Documento {item.documentId}</p> : null}
                                <p className="mt-2 text-xs text-slate-500">{formatDateTime(item.createdAt)}</p>
                                {rejectionReason ? (
                                  <p className="mt-2 text-sm text-amber-950">
                                    <strong>Motivo:</strong> {rejectionReason}
                                  </p>
                                ) : null}
                                <div className="mt-3 flex flex-wrap items-center gap-3">
                                  <Button type="button" variant="outline" className="rounded-full bg-white/90 text-slate-700" onClick={() => focusAuditItem(item)}>
                                    {drilldown.label}
                                  </Button>
                                  <span className="text-xs font-medium text-slate-500">{drilldown.helper}</span>
                                </div>
                              </article>
                            );
                          })
                        ) : (
                          <SectionEmptyState
                            title="No hay eventos operativos para la combinación rápida actual"
                            description="Quita filtros rápidos de familia o severidad, o bien relaja tenant y caso para recuperar trazabilidad reciente desde la auditoría persistida."
                            onClear={clearAuditFeedFilters}
                          />
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="rounded-[1.4rem] border border-slate-200 bg-slate-50/70 p-4">
                    <div>
                      <h4 className="text-base font-semibold text-slate-950">Lectura rápida</h4>
                      <p className="mt-1 text-sm text-slate-500">Resumen ejecutivo mínimo para monitorear fricción, trazabilidad y acumulación de rechazos operativos.</p>
                    </div>
                    <div className="mt-4 space-y-3">
                      <div className="rounded-2xl border border-amber-200 bg-amber-50/70 p-4 shadow-sm">
                        <div className="flex items-center justify-between gap-3">
                          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-amber-800">Alertas ejecutivas derivadas</p>
                          <Badge className="rounded-full border border-amber-200 bg-white text-amber-800">{formatNumber(auditExecutiveAlerts.length)}</Badge>
                        </div>
                        <div className="mt-3 space-y-3">
                          {auditExecutiveAlerts.length > 0 ? (
                            auditExecutiveAlerts.map((alert) => (
                              <article key={`${alert.scope}-${alert.scopeId}`} className="rounded-2xl border border-white/80 bg-white/90 p-3">
                                <div className="flex flex-wrap items-center gap-2">
                                  <Badge className={`rounded-full border ${getSeverityBadgeClass(alert.severity)}`}>{getAuditSeverityLabel(alert.severity)}</Badge>
                                  <Badge className="rounded-full border border-slate-200 bg-slate-100 text-slate-700">{alert.scope === "case" ? "Caso" : "Tenant"}</Badge>
                                  <Badge className="rounded-full border border-slate-200 bg-slate-100 text-slate-700">{formatNumber(alert.rejectionCount)} rechazos</Badge>
                                </div>
                                <p className="mt-3 text-sm font-semibold text-slate-950">{alert.title}</p>
                                <p className="mt-2 text-sm leading-6 text-slate-600">{alert.description}</p>
                                <Button type="button" variant="outline" className="mt-3 rounded-full bg-white text-slate-700" onClick={() => focusExecutiveAlert(alert)}>
                                  Revisar contexto
                                </Button>
                              </article>
                            ))
                          ) : (
                            <p className="rounded-2xl bg-white px-4 py-3 text-sm text-slate-600">Aún no se acumulan rechazos suficientes por tenant o caso para disparar una alerta ejecutiva derivada.</p>
                          )}
                        </div>
                      </div>
                      <div className="rounded-2xl bg-white p-4 shadow-sm">
                        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Accesos auditados</p>
                        <p className="mt-2 text-xl font-semibold text-slate-950">{formatNumber(auditSummary.accessEvents)}</p>
                        <p className="mt-2 text-sm text-slate-500">Cambios de membresías y superficie de acceso trazable.</p>
                      </div>
                      <div className="rounded-2xl bg-white p-4 shadow-sm">
                        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Políticas auditadas</p>
                        <p className="mt-2 text-xl font-semibold text-slate-950">{formatNumber(auditSummary.policyEvents)}</p>
                        <p className="mt-2 text-sm text-slate-500">Cambios de consentimiento o visibilidad ya persistidos.</p>
                      </div>
                      <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-4 shadow-sm">
                        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Último guardrail</p>
                        <p className="mt-2 text-sm font-semibold text-slate-950">
                          {latestGuardrailEvent ? formatDateTime(latestGuardrailEvent.createdAt) : "Sin eventos de rechazo recientes"}
                        </p>
                        <p className="mt-2 text-sm text-slate-500">
                          {latestGuardrailEvent
                            ? getAuditRejectionReason(latestGuardrailEvent) || "El rechazo quedó registrado con traza mínima en auditoría."
                            : "Cuando un guardrail operativo bloquee una acción de Auditar, aparecerá aquí con su razón resumida."}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
                <section className="space-y-6">
                  <div className="rounded-[1.8rem] border border-white/70 bg-white/92 p-5 shadow-[0_24px_70px_-34px_rgba(15,23,42,0.18)]">
                    <div className="flex items-center justify-between gap-4">
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Estado de operación</p>
                        <h3 className="mt-1 text-xl font-semibold tracking-tight text-slate-950">Salud por tenant</h3>
                      </div>
                      <Badge className="rounded-full border border-teal-200 bg-teal-50 text-teal-700">
                        {formatNumber(snapshotData.tenantHealth.length)} organizaciones visibles
                      </Badge>
                    </div>
                    <div className="mt-5 space-y-3">
                      {snapshotData.tenantHealth.length > 0 ? (
                        snapshotData.tenantHealth.map((tenant) => (
                          <article
                            key={tenant.tenantId}
                            className="grid gap-4 rounded-[1.4rem] border border-slate-200/80 bg-slate-50/70 p-4 lg:grid-cols-[minmax(0,1fr)_auto]"
                          >
                            <div className="space-y-2">
                              <div className="flex flex-wrap items-center gap-2">
                                <p className="text-base font-semibold text-slate-950">{tenant.tenantName}</p>
                                <Badge className={`rounded-full border ${getStatusBadgeClass(tenant.status)}`}>{tenant.status}</Badge>
                              </div>
                              <p className="text-sm text-slate-500">Actualizado: {formatDateTime(tenant.updatedAt)}</p>
                            </div>
                            <div className="grid min-w-[280px] grid-cols-2 gap-3 text-sm text-slate-600 sm:grid-cols-4 lg:min-w-[360px]">
                              <div className="rounded-2xl bg-white px-3 py-2">
                                <p className="text-[11px] uppercase tracking-[0.16em] text-slate-400">Casos</p>
                                <strong className="text-base text-slate-950">{formatNumber(tenant.activeCases)}</strong>
                              </div>
                              <div className="rounded-2xl bg-white px-3 py-2">
                                <p className="text-[11px] uppercase tracking-[0.16em] text-slate-400">Alertas</p>
                                <strong className="text-base text-slate-950">{formatNumber(tenant.openAlerts)}</strong>
                              </div>
                              <div className="rounded-2xl bg-white px-3 py-2">
                                <p className="text-[11px] uppercase tracking-[0.16em] text-slate-400">Membresías</p>
                                <strong className="text-base text-slate-950">{formatNumber(tenant.activeMemberships)}</strong>
                              </div>
                              <div className="rounded-2xl bg-white px-3 py-2">
                                <p className="text-[11px] uppercase tracking-[0.16em] text-slate-400">Docs pendientes</p>
                                <strong className="text-base text-slate-950">{formatNumber(tenant.pendingDocuments)}</strong>
                              </div>
                            </div>
                          </article>
                        ))
                      ) : (
                        <SectionEmptyState
                          title="No hay tenants que coincidan con el filtro actual"
                          description="Ajusta la búsqueda o amplía la ventana temporal para recuperar visibilidad de organizaciones, casos y señales operativas."
                          onClear={clearAllFilters}
                        />
                      )}
                    </div>
                  </div>

                  <div className="rounded-[1.8rem] border border-white/70 bg-white/92 p-5 shadow-[0_24px_70px_-34px_rgba(15,23,42,0.18)]">
                    <div className="flex items-center justify-between gap-4">
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Expedientes recientes</p>
                        <h3 className="mt-1 text-xl font-semibold tracking-tight text-slate-950">Casos con actividad más reciente</h3>
                      </div>
                      <Badge className="rounded-full border border-slate-200 bg-slate-100 text-slate-700">
                        {formatNumber(snapshotData.recentCases.length)} visibles
                      </Badge>
                    </div>
                    <div className="mt-5 overflow-hidden rounded-[1.4rem] border border-slate-200">
                      {snapshotData.recentCases.length > 0 ? (
                        <>
                          <div className="grid grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)_auto_auto_auto] gap-3 bg-slate-100 px-4 py-3 text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">
                            <span>Caso</span>
                            <span>Tenant</span>
                            <span>Estatus</span>
                            <span>Última actividad</span>
                            <span className="text-right">Acción segura</span>
                          </div>
                          <div className="divide-y divide-slate-200 bg-white">
                            {snapshotData.recentCases.map((item) => {
                              const actionLabel = getSafeCaseActionLabel(item.status);
                              return (
                                <div key={item.caseId} className="grid grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)_auto_auto_auto] gap-3 px-4 py-4 text-sm">
                                  <div className="min-w-0">
                                    <p className="truncate font-semibold text-slate-950">{item.title}</p>
                                    <p className="truncate text-slate-500">{item.caseId}</p>
                                  </div>
                                  <div className="min-w-0 text-slate-600">{item.tenantName}</div>
                                  <div>
                                    <Badge className={`rounded-full border ${getStatusBadgeClass(item.status)}`}>{item.status}</Badge>
                                  </div>
                                  <div className="text-right text-slate-500">{formatDateTime(item.lastActivityAt ?? item.updatedAt)}</div>
                                  <div className="flex justify-end">
                                    {actionLabel ? (
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        className="rounded-full bg-white"
                                        disabled={executiveActionsBlocked || isCaseBusy(item.tenantId, item.caseId)}
                                        onClick={() => {
                                          requestCaseAction(item.tenantId, item.caseId, item.title, item.status);
                                        }}
                                      >
                                        {isCaseBusy(item.tenantId, item.caseId) ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                                        {actionLabel}
                                      </Button>
                                    ) : (
                                      <span className="text-xs text-slate-400">Sin acción segura</span>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </>
                      ) : (
                        <div className="bg-white p-4">
                          <SectionEmptyState
                            title="No hay expedientes visibles para esta combinación"
                            description="Puedes quitar el filtro de caso, usuario o severidad para recuperar una vista más amplia del pipeline operativo."
                            onClear={clearAllFilters}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </section>

                <section className="space-y-6">
                  <div className="rounded-[1.8rem] border border-white/70 bg-white/92 p-5 shadow-[0_24px_70px_-34px_rgba(15,23,42,0.18)]">
                    <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Distribución</p>
                    <h3 className="mt-1 text-xl font-semibold tracking-tight text-slate-950">Señales operativas del momento</h3>
                    <div className="mt-5 space-y-4">
                      <div className="rounded-[1.4rem] border border-slate-200 bg-slate-50/70 p-4">
                        <div className="flex items-center gap-2 text-slate-950">
                          <Building2 className="h-4 w-4 text-teal-700" />
                          <p className="font-semibold">Casos por estatus</p>
                        </div>
                        <div className="mt-4 space-y-3">
                          {baseSnapshotQuery.data?.casesByStatus.map((item) => (
                            <div key={item.status}>
                              <div className="mb-1 flex items-center justify-between text-sm text-slate-600">
                                <span>{item.status}</span>
                                <span>{formatNumber(item.total)}</span>
                              </div>
                              <div className="h-2.5 overflow-hidden rounded-full bg-slate-200">
                                <div
                                  className="h-full rounded-full bg-teal-500"
                                  style={{
                                    width: `${Math.max(8, (item.total / Math.max(globalSummary.activeCases || 1, 1)) * 100)}%`,
                                  }}
                                />
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="rounded-[1.4rem] border border-slate-200 bg-slate-50/70 p-4">
                        <div className="flex items-center gap-2 text-slate-950">
                          <ShieldCheck className="h-4 w-4 text-cyan-700" />
                          <p className="font-semibold">Alertas por severidad</p>
                        </div>
                        <div className="mt-4 space-y-3">
                          {baseSnapshotQuery.data?.alertsBySeverity.map((item) => (
                            <div key={item.severity} className="flex items-center justify-between rounded-2xl bg-white px-3 py-3 text-sm">
                              <Badge className={`rounded-full border ${getSeverityBadgeClass(item.severity)}`}>{item.severity}</Badge>
                              <strong className="text-slate-950">{formatNumber(item.total)}</strong>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-[1.8rem] border border-white/70 bg-white/92 p-5 shadow-[0_24px_70px_-34px_rgba(15,23,42,0.18)]">
                    <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Pendientes del CEO</p>
                    <h3 className="mt-1 text-xl font-semibold tracking-tight text-slate-950">Prioridades para seguimiento</h3>
                    <div className="mt-5 space-y-3 text-sm text-slate-700">
                      <div className="rounded-[1.3rem] border border-amber-200 bg-amber-50 px-4 py-3">
                        Hay <strong>{formatNumber(globalSummary.pendingConsents)}</strong> consentimientos pendientes de resolver.
                      </div>
                      <div className="rounded-[1.3rem] border border-rose-200 bg-rose-50 px-4 py-3">
                        Existen <strong>{formatNumber(globalSummary.criticalAlerts)}</strong> alertas críticas que merecen revisión ejecutiva.
                      </div>
                      <div className="rounded-[1.3rem] border border-cyan-200 bg-cyan-50 px-4 py-3">
                        Se registran <strong>{formatNumber(globalSummary.caseScopedMemberships)}</strong> accesos de alcance por caso actualmente activos.
                      </div>
                    </div>
                  </div>
                </section>
              </div>
            </>
          ) : null}

          {currentSection === "bridge" ? (
            <div className="space-y-5">
              <section className="rounded-[1.8rem] border border-white/70 bg-white/92 p-5 shadow-[0_24px_70px_-34px_rgba(15,23,42,0.18)]">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Observabilidad bridge</p>
                    <h3 className="mt-1 text-xl font-semibold tracking-tight text-slate-950">Snapshot operativo CompliLink ↔ AuditaPatron</h3>
                  </div>
                  <Badge className="rounded-full border border-sky-200 bg-sky-50 text-sky-700">
                    {formatNumber(bridgeOverview.rows.length)} expedientes trazados
                  </Badge>
                </div>
                <p className="mt-4 max-w-3xl text-sm leading-6 text-slate-600">
                  Esta vista concentra el estado operativo del bridge usando el feed de auditoría ya disponible: envíos recientes, expedientes pendientes de retorno,
                  fallos permanentes y advertencias que todavía requieren seguimiento manual.
                </p>
                <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                  <article className="rounded-[1.4rem] border border-rose-200 bg-rose-50/80 p-4">
                    <div className="flex items-center gap-3">
                      <Siren className="h-5 w-5 text-rose-600" />
                      <div>
                        <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-rose-700">Críticos</p>
                        <p className="mt-1 text-2xl font-semibold tracking-tight text-rose-950">{formatNumber(bridgeOverview.summary.critical)}</p>
                      </div>
                    </div>
                    <p className="mt-3 text-sm text-rose-900/80">Fallo permanente, guardrail activo o incidente con riesgo operativo inmediato.</p>
                  </article>
                  <article className="rounded-[1.4rem] border border-amber-200 bg-amber-50/80 p-4">
                    <div className="flex items-center gap-3">
                      <AlertTriangle className="h-5 w-5 text-amber-600" />
                      <div>
                        <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-amber-700">Advertencias</p>
                        <p className="mt-1 text-2xl font-semibold tracking-tight text-amber-950">{formatNumber(bridgeOverview.summary.warning)}</p>
                      </div>
                    </div>
                    <p className="mt-3 text-sm text-amber-900/80">Eventos con retry, inconsistencias o alertas abiertas ligadas al retorno documental.</p>
                  </article>
                  <article className="rounded-[1.4rem] border border-sky-200 bg-sky-50/80 p-4">
                    <div className="flex items-center gap-3">
                      <Clock3 className="h-5 w-5 text-sky-600" />
                      <div>
                        <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-sky-700">Pendientes</p>
                        <p className="mt-1 text-2xl font-semibold tracking-tight text-sky-950">{formatNumber(bridgeOverview.summary.pending)}</p>
                      </div>
                    </div>
                    <p className="mt-3 text-sm text-sky-900/80">Expedientes que ya salieron al bridge y siguen esperando webhook o confirmación final.</p>
                  </article>
                  <article className="rounded-[1.4rem] border border-emerald-200 bg-emerald-50/80 p-4">
                    <div className="flex items-center gap-3">
                      <ShieldCheck className="h-5 w-5 text-emerald-600" />
                      <div>
                        <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-emerald-700">Conformes</p>
                        <p className="mt-1 text-2xl font-semibold tracking-tight text-emerald-950">{formatNumber(bridgeOverview.summary.healthy)}</p>
                      </div>
                    </div>
                    <p className="mt-3 text-sm text-emerald-900/80">Retornos procesados sin alertas abiertas en el expediente visible.</p>
                  </article>
                </div>
              </section>

              <section className="grid gap-5 xl:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)]">
                <article className="rounded-[1.8rem] border border-white/70 bg-white/92 p-5 shadow-[0_24px_70px_-34px_rgba(15,23,42,0.18)]">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Cola priorizada</p>
                      <h3 className="mt-1 text-xl font-semibold tracking-tight text-slate-950">Expedientes que requieren revisión</h3>
                    </div>
                    <Badge className="rounded-full border border-slate-200 bg-slate-50 text-slate-700">
                      {formatNumber(bridgeOverview.issues.length)} en foco
                    </Badge>
                  </div>
                  <div className="mt-5 space-y-3">
                    {bridgeOverview.issues.length > 0 ? (
                      bridgeOverview.issues.map((item) => (
                        <article key={item.documentId} className="rounded-[1.4rem] border border-slate-200 bg-slate-50/70 p-4">
                          <div className="flex flex-wrap items-start justify-between gap-3">
                            <div className="space-y-2">
                              <div className="flex flex-wrap items-center gap-2">
                                <Badge className={`rounded-full border ${getBridgeHealthBadgeClass(item.health)}`}>{item.health}</Badge>
                                <Badge className="rounded-full border border-slate-200 bg-white text-slate-700">{getBridgeOutcomeLabel(item.outcomeCategory)}</Badge>
                                {item.openAlertCount > 0 ? (
                                  <Badge className="rounded-full border border-amber-200 bg-amber-50 text-amber-700">
                                    {formatNumber(item.openAlertCount)} alerta{item.openAlertCount === 1 ? "" : "s"}
                                  </Badge>
                                ) : null}
                              </div>
                              <p className="text-lg font-semibold text-slate-950">{item.documentName || item.documentId}</p>
                              <p className="text-sm text-slate-600">
                                {item.tenantName} · {item.caseTitle || item.caseId || "Sin caso asociado"}
                              </p>
                              <p className="text-sm text-slate-500">
                                Último evento: {formatDateTime(item.lastActivityAt)} · Intentos {formatNumber(item.attempts)}
                              </p>
                              {item.guardrailReason || item.errorMessage ? (
                                <p className="rounded-2xl border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-950">
                                  <strong>Detalle:</strong> {item.guardrailReason || item.errorMessage}
                                </p>
                              ) : null}
                              {item.warnings.length > 0 ? (
                                <div className="rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-600">
                                  <strong className="text-slate-950">Warnings:</strong> {item.warnings.join(" · ")}
                                </div>
                              ) : null}
                            </div>
                            <div className="min-w-[250px] rounded-2xl bg-white px-4 py-3 text-sm text-slate-600">
                              <p><strong className="text-slate-950">Trace:</strong> {item.traceId || "Sin traza"}</p>
                              <p><strong className="text-slate-950">CompliLink ID:</strong> {item.compliLinkId || "Pendiente"}</p>
                              <p><strong className="text-slate-950">Dispatch:</strong> {formatDateTime(item.dispatchedAt)}</p>
                              <p><strong className="text-slate-950">Retorno:</strong> {formatDateTime(item.returnedAt)}</p>
                              <p><strong className="text-slate-950">HTTP:</strong> {item.httpStatusCode ?? "Sin respuesta"}</p>
                            </div>
                          </div>
                        </article>
                      ))
                    ) : (
                      <div className="rounded-[1.4rem] border border-dashed border-emerald-200 bg-emerald-50/70 px-5 py-8 text-sm text-emerald-900">
                        No hay expedientes bridge con atención inmediata en la vista actual.
                      </div>
                    )}
                  </div>
                </article>

                <article className="rounded-[1.8rem] border border-white/70 bg-white/92 p-5 shadow-[0_24px_70px_-34px_rgba(15,23,42,0.18)]">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Señales operativas</p>
                      <h3 className="mt-1 text-xl font-semibold tracking-tight text-slate-950">Lectura rápida del carril bridge</h3>
                    </div>
                    <GitBranch className="h-5 w-5 text-slate-400" />
                  </div>
                  <div className="mt-5 space-y-3 text-sm text-slate-600">
                    <div className="rounded-[1.4rem] border border-slate-200 bg-slate-50/80 p-4">
                      <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">Pendientes de retorno</p>
                      <p className="mt-2 text-2xl font-semibold tracking-tight text-slate-950">{formatNumber(bridgeOverview.summary.pending)}</p>
                      <p className="mt-2">Útil para detectar cuellos de botella entre dispatch y webhook final.</p>
                    </div>
                    <div className="rounded-[1.4rem] border border-slate-200 bg-slate-50/80 p-4">
                      <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">Reintentos o warnings</p>
                      <p className="mt-2 text-2xl font-semibold tracking-tight text-slate-950">{formatNumber(bridgeOverview.summary.warning)}</p>
                      <p className="mt-2">Revisa especialmente expedientes con múltiples intentos y alertas abiertas de integridad.</p>
                    </div>
                    <div className="rounded-[1.4rem] border border-slate-200 bg-slate-50/80 p-4">
                      <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">Fallo permanente</p>
                      <p className="mt-2 text-2xl font-semibold tracking-tight text-slate-950">{formatNumber(bridgeOverview.summary.critical)}</p>
                      <p className="mt-2">Prioridad máxima para soporte operativo o corrección manual del expediente.</p>
                    </div>
                  </div>
                </article>
              </section>

              <section className="rounded-[1.8rem] border border-white/70 bg-white/92 p-5 shadow-[0_24px_70px_-34px_rgba(15,23,42,0.18)]">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Actividad reciente</p>
                    <h3 className="mt-1 text-xl font-semibold tracking-tight text-slate-950">Timeline resumido por expediente</h3>
                  </div>
                  <Badge className="rounded-full border border-slate-200 bg-slate-50 text-slate-700">
                    Ordenado por evento más reciente
                  </Badge>
                </div>
                <div className="mt-5 overflow-x-auto">
                  <table className="min-w-full divide-y divide-slate-200 text-sm">
                    <thead>
                      <tr className="text-left text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">
                        <th className="pb-3 pr-4">Documento</th>
                        <th className="pb-3 pr-4">Tenant / caso</th>
                        <th className="pb-3 pr-4">Estado</th>
                        <th className="pb-3 pr-4">Resultado</th>
                        <th className="pb-3 pr-4">Intentos</th>
                        <th className="pb-3 pr-4">Último evento</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {bridgeOverview.rows.length > 0 ? (
                        bridgeOverview.rows.map((item) => (
                          <tr key={item.documentId} className="align-top text-slate-600">
                            <td className="py-4 pr-4">
                              <p className="font-semibold text-slate-950">{item.documentName || item.documentId}</p>
                              <p className="mt-1 text-xs text-slate-500">{item.traceId || "Sin traza"}</p>
                            </td>
                            <td className="py-4 pr-4">
                              <p>{item.tenantName}</p>
                              <p className="mt-1 text-xs text-slate-500">{item.caseTitle || item.caseId || "Sin caso asociado"}</p>
                            </td>
                            <td className="py-4 pr-4">
                              <Badge className={`rounded-full border ${getBridgeHealthBadgeClass(item.health)}`}>{item.health}</Badge>
                            </td>
                            <td className="py-4 pr-4">{getBridgeOutcomeLabel(item.outcomeCategory)}</td>
                            <td className="py-4 pr-4">{formatNumber(item.attempts)}</td>
                            <td className="py-4 pr-4">{formatDateTime(item.lastActivityAt)}</td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={6} className="py-10 text-center text-sm text-slate-500">
                            Aún no hay actividad del bridge disponible para los filtros seleccionados.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </section>
            </div>
          ) : null}

          {currentSection === "alertas" ? (
            <section className="rounded-[1.8rem] border border-white/70 bg-white/92 p-5 shadow-[0_24px_70px_-34px_rgba(15,23,42,0.18)]">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Alertas accionables</p>
                  <h3 className="mt-1 text-xl font-semibold tracking-tight text-slate-950">Vista ejecutiva de alertas</h3>
                </div>
                <Badge className="rounded-full border border-rose-200 bg-rose-50 text-rose-700">
                  {formatNumber(snapshotData.recentAlerts.length)} visibles
                </Badge>
              </div>
              <div className="mt-5 space-y-3">
                {snapshotData.recentAlerts.length > 0 ? (
                  snapshotData.recentAlerts.map((alert) => {
                    const actionLabel = getSafeAlertActionLabel(alert.status);
                    return (
                      <article key={alert.id} className="rounded-[1.4rem] border border-slate-200 bg-slate-50/70 p-4">
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <div className="space-y-2">
                            <div className="flex flex-wrap items-center gap-2">
                              <Badge className={`rounded-full border ${getSeverityBadgeClass(alert.severity)}`}>{alert.severity}</Badge>
                              <Badge className={`rounded-full border ${getStatusBadgeClass(alert.status)}`}>{alert.status}</Badge>
                              <span className="text-xs uppercase tracking-[0.16em] text-slate-400">{alert.category}</span>
                            </div>
                            <h4 className="text-lg font-semibold text-slate-950">{alert.title}</h4>
                            <p className="max-w-3xl text-sm leading-6 text-slate-600">{alert.description || "Sin descripción adicional."}</p>
                          </div>
                          <div className="min-w-[260px] rounded-2xl bg-white px-4 py-3 text-sm text-slate-600">
                            <p><strong className="text-slate-950">Tenant:</strong> {alert.tenantName}</p>
                            <p><strong className="text-slate-950">Caso:</strong> {alert.caseTitle || alert.caseId || "Sin caso"}</p>
                            <p><strong className="text-slate-950">Detectada:</strong> {formatDateTime(alert.raisedAt)}</p>
                            <p><strong className="text-slate-950">Resuelta:</strong> {formatDateTime(alert.resolvedAt)}</p>
                            <div className="mt-3">
                              {actionLabel ? (
                                <Button
                                  className="w-full rounded-full"
                                  size="sm"
                                  disabled={executiveActionsBlocked || isAlertBusy(alert.id)}
                                  onClick={() => {
                                    requestAlertAction(alert.id, alert.title, alert.status);
                                  }}
                                >
                                  {isAlertBusy(alert.id) ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                                  {actionLabel}
                                </Button>
                              ) : (
                                <p className="text-xs text-slate-400">Esta alerta ya no tiene una transición segura disponible.</p>
                              )}
                            </div>
                          </div>
                        </div>
                      </article>
                    );
                  })
                ) : (
                  <SectionEmptyState
                    title="No se encontraron alertas con estos filtros"
                    description="Puedes relajar la severidad, ampliar el rango temporal o eliminar la búsqueda actual para volver a ver incidentes abiertos o atendidos."
                    onClear={clearAllFilters}
                  />
                )}
              </div>
            </section>
          ) : null}

          {currentSection === "accesos" ? (
            <section className="rounded-[1.8rem] border border-white/70 bg-white/92 p-5 shadow-[0_24px_70px_-34px_rgba(15,23,42,0.18)]">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Membresías activas</p>
                  <h3 className="mt-1 text-xl font-semibold tracking-tight text-slate-950">Accesos por tenant y por caso</h3>
                </div>
                <Badge className="rounded-full border border-cyan-200 bg-cyan-50 text-cyan-700">
                  {formatNumber(snapshotData.recentMemberships.length)} visibles
                </Badge>
              </div>
              <div className="mt-5 grid gap-3">
                {snapshotData.recentMemberships.length > 0 ? (
                  snapshotData.recentMemberships.map((membership) => {
                    const action = getSafeMembershipAction(membership);
                    const userLabel = membership.userName || membership.userEmail || `Usuario ${membership.userId}`;
                    return (
                      <article key={membership.id} className="grid gap-4 rounded-[1.4rem] border border-slate-200 bg-slate-50/70 p-4 lg:grid-cols-[minmax(0,1fr)_auto]">
                        <div className="space-y-2">
                          <div className="flex flex-wrap items-center gap-2">
                            <p className="text-lg font-semibold text-slate-950">{userLabel}</p>
                            <Badge className={`rounded-full border ${getStatusBadgeClass(membership.status)}`}>{membership.status}</Badge>
                            <Badge className="rounded-full border border-slate-200 bg-white text-slate-700">{membership.role}</Badge>
                            <Badge className="rounded-full border border-slate-200 bg-white text-slate-700">{membership.accessScope}</Badge>
                          </div>
                          <p className="text-sm text-slate-600">{membership.userEmail || "Sin correo visible"}</p>
                          <p className="text-sm text-slate-600">
                            <strong className="text-slate-950">Tenant:</strong> {membership.tenantName}
                            {membership.caseTitle || membership.caseId ? (
                              <>
                                {" · "}
                                <strong className="text-slate-950">Caso:</strong> {membership.caseTitle || membership.caseId}
                              </>
                            ) : null}
                          </p>
                        </div>
                        <div className="min-w-[260px] rounded-2xl bg-white px-4 py-3 text-sm text-slate-600">
                          <p><strong className="text-slate-950">Creado:</strong> {formatDateTime(membership.createdAt)}</p>
                          <p><strong className="text-slate-950">Actualizado:</strong> {formatDateTime(membership.updatedAt)}</p>
                          <p><strong className="text-slate-950">Usuario ID:</strong> {membership.userId}</p>
                          <div className="mt-3">
                            {action ? (
                              <Button
                                variant="outline"
                                className="w-full rounded-full bg-white"
                                size="sm"
                                disabled={executiveActionsBlocked || isMembershipBusy(membership.id)}
                                onClick={() => {
                                  requestMembershipAction(membership.id, membership, userLabel);
                                }}
                              >
                                {isMembershipBusy(membership.id) ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                                {action.label}
                              </Button>
                            ) : (
                              <p className="text-xs text-slate-400">Sólo los accesos acotados a un caso pueden operarse desde este bloque seguro.</p>
                            )}
                          </div>
                        </div>
                      </article>
                    );
                  })
                ) : (
                  <SectionEmptyState
                    title="No se encontraron accesos con el filtro actual"
                    description="Prueba limpiar el usuario, el caso o la búsqueda transversal para volver a revisar membresías y permisos vigentes."
                    onClear={clearAllFilters}
                  />
                )}
              </div>
            </section>
          ) : null}

          {currentSection === "documentos" ? (
            <section className="rounded-[1.8rem] border border-white/70 bg-white/92 p-5 shadow-[0_24px_70px_-34px_rgba(15,23,42,0.18)]">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Trazabilidad documental</p>
                  <h3 className="mt-1 text-xl font-semibold tracking-tight text-slate-950">Versionado y supersedencia visible</h3>
                </div>
                <Badge className="rounded-full border border-amber-200 bg-amber-50 text-amber-700">
                  {formatNumber(snapshotData.recentDocuments.length)} visibles
                </Badge>
              </div>
              <div className="mt-5 space-y-3">
                {snapshotData.recentDocuments.length > 0 ? (
                  snapshotData.recentDocuments.map((document) => (
                    <article key={document.documentId} className="rounded-[1.4rem] border border-slate-200 bg-slate-50/70 p-4">
                      <div className="flex flex-wrap items-start justify-between gap-4">
                        <div className="max-w-3xl space-y-2">
                          <div className="flex flex-wrap items-center gap-2">
                            <Badge className={`rounded-full border ${getStatusBadgeClass(document.integrityStatus)}`}>{document.integrityStatus}</Badge>
                            <Badge className="rounded-full border border-slate-200 bg-white text-slate-700">{document.documentType}</Badge>
                            <Badge className="rounded-full border border-slate-200 bg-white text-slate-700">{document.visibility}</Badge>
                          </div>
                          <h4 className="text-lg font-semibold text-slate-950">{document.originalName}</h4>
                          <p className="text-sm text-slate-600">
                            <strong className="text-slate-950">Tenant:</strong> {document.tenantName}
                            {" · "}
                            <strong className="text-slate-950">Caso:</strong> {document.caseTitle || document.caseId}
                          </p>
                          <p className="text-sm text-slate-600">
                            <strong className="text-slate-950">Trace ID:</strong> {document.traceId}
                            {" · "}
                            <strong className="text-slate-950">Confianza:</strong>{" "}
                            {typeof document.classificationConfidence === "number"
                              ? `${Math.round(document.classificationConfidence * 100)}%`
                              : "N/D"}
                          </p>
                          <p className="text-sm text-slate-600">
                            <strong className="text-slate-950">Consentimiento:</strong> {document.consentStatus}
                          </p>
                        </div>
                        <div className="min-w-[280px] rounded-2xl bg-white px-4 py-3 text-sm text-slate-600">
                          <p><strong className="text-slate-950">Creado:</strong> {formatDateTime(document.createdAt)}</p>
                          <p><strong className="text-slate-950">Actualizado:</strong> {formatDateTime(document.updatedAt)}</p>
                          <p><strong className="text-slate-950">Supersede a:</strong> {document.supersededDocument?.originalName || document.supersedesDocumentId || "No aplica"}</p>
                          <p><strong className="text-slate-950">Estado previo:</strong> {document.supersededDocument?.integrityStatus || "—"}</p>
                        </div>
                      </div>
                    </article>
                  ))
                ) : (
                  <SectionEmptyState
                    title="No hay documentos que coincidan con esta búsqueda"
                    description="Puedes quitar el filtro por caso, relajar la ventana temporal o eliminar la búsqueda para volver a explorar el versionado documental."
                    onClear={clearAllFilters}
                  />
                )}
              </div>
            </section>
          ) : null}
        </div>
      )}
      <AlertDialog
        open={Boolean(pendingExecutiveAction)}
        onOpenChange={(open) => {
          if (!open && !isConfirmingExecutiveAction) {
            setPendingExecutiveAction(null);
          }
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {pendingExecutiveAction?.kind === "case"
                ? "Confirmar avance operativo"
                : pendingExecutiveAction?.kind === "membership"
                  ? "Confirmar cambio de acceso"
                  : "Confirmar actualización de alerta"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              La consola ejecutará esta acción sólo si el backend confirma que el estado visible sigue vigente. Si la vista cambió o perdió frescura, la operación se bloqueará.
            </AlertDialogDescription>
          </AlertDialogHeader>
          {pendingExecutiveAction ? (
            <div className="rounded-2xl border border-slate-200 bg-slate-50/80 px-4 py-3 text-sm text-slate-700">
              <p>
                <strong className="text-slate-950">Acción:</strong> {pendingExecutiveAction.actionLabel}
              </p>
              <p>
                <strong className="text-slate-950">Estado visible:</strong> {pendingExecutiveAction.currentStatus}
              </p>
              <p>
                <strong className="text-slate-950">Contexto:</strong>{" "}
                {pendingExecutiveAction.kind === "case"
                  ? `${pendingExecutiveAction.title} · ${pendingExecutiveAction.caseId}`
                  : pendingExecutiveAction.kind === "membership"
                    ? pendingExecutiveAction.userLabel
                    : pendingExecutiveAction.title}
              </p>
              <p className="mt-2 text-xs text-slate-500">
                {executiveGuardrailDescription}
              </p>
            </div>
          ) : null}
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isConfirmingExecutiveAction}>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              disabled={isConfirmingExecutiveAction || executiveActionsBlocked}
              onClick={() => {
                if (pendingExecutiveAction) {
                  void executePendingExecutiveAction(pendingExecutiveAction);
                }
              }}
            >
              {isConfirmingExecutiveAction ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Confirmar y registrar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  );
}
