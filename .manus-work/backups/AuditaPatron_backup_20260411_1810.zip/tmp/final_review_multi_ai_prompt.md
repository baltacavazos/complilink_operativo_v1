# Prompt de revisión final multi-IA

Eres parte de un consejo de revisión final de producto. Debes evaluar una landing/home ya existente de **AuditaPatron**.

## Objetivo

Encontrar mejoras de **máximo impacto** y **mínimo cambio estructural** para acercar la página a un resultado **10/10**, priorizando:

1. **Simplicidad extrema**.
2. **Engagement emocional**.
3. **Deseo irresistible de probar el producto**.
4. **Mayor claridad del beneficio desde el primer pantallazo**.
5. **Cero rediseños grandes** ni cambios estructurales profundos.

## Contexto del producto

AuditaPatron ayuda a trabajadores a subir documentos laborales y obtener claridad, orden, contexto y resguardo dentro de un expediente digital. La página actual ya tiene un hero claro, una estética limpia y varias secciones sobre cómo funciona, crecimiento del expediente, asistente laboral, privacidad y preguntas frecuentes.

## Hallazgos iniciales del moderador

- El hero comunica bien el producto, pero todavía se siente más racional que visceral.
- La página genera comprensión, pero aún no maximiza el deseo emocional.
- Algunas secciones repiten ideas similares sin aumentar suficiente tensión persuasiva.
- El CTA principal es visible, pero todavía puede sentirse más inevitable.
- La oportunidad mayor parece estar en **copy, jerarquía, intensidad emocional, microfricción positiva y compresión narrativa**, no en rehacer la estructura.

## Estructura resumida actual

- Header con navegación: Cómo funciona, Tu expediente, Asistente, Preguntas.
- Hero con gran titular sobre derechos laborales claros desde el primer documento.
- CTAs principales: "Abrir mi expediente" y "Ver cómo funciona".
- Tarjeta visual derecha con progreso, beneficios y siguiente paso sugerido.
- Sección de cómo funciona en 3 pasos.
- Sección sobre expediente en crecimiento.
- Sección de documentos que más ayudan.
- Sección del asistente laboral.
- Sección de privacidad/control.
- FAQ y footer legal.

## Fragmentos representativos del copy actual

- "Tus derechos laborales, claros desde el primer documento que subes."
- "Sube tus documentos y deja que AuditaPatron los analice, los resguarde y te devuelva resultados útiles dentro de AuditaPatron."
- "Entiende tu situación sin complicarte."
- "Cada documento útil se convierte en orden, claridad y respaldo."
- "Una capa extra para hacer preguntas rápidas sobre tu expediente."
- "Tus archivos se resguardan para ayudarte, no para confundirte."

## Tarea

Haz una crítica experta y propone solo mejoras **pequeñas o medianas**, sin cambiar la estructura global del sitio.

## Responde con esta estructura exacta

### 1. Diagnóstico breve
Explica en un párrafo qué está funcionando y qué impide que esta home llegue a 10/10.

### 2. Top 5 mejoras de mayor impacto
Entrega una tabla con columnas: `Prioridad`, `Área`, `Problema actual`, `Cambio propuesto`, `Impacto esperado`, `Costo estructural`.

### 3. Ajustes concretos de copy de alto impacto
Propón:
- un mejor titular de hero,
- un mejor subtítulo,
- una mejor etiqueta o microcopy para el CTA principal,
- una mejora para la tarjeta de progreso/lado derecho.

### 4. Engagement emocional
Explica cómo aumentar alivio, curiosidad, protección, control y urgencia sin caer en manipulación ni alarmismo.

### 5. Qué NO tocar
Di explícitamente qué partes no conviene cambiar para no romper simplicidad ni introducir deuda innecesaria.

### 6. Puntuación actual y puntuación potencial
Evalúa la home actual sobre 10 y la versión mejorada sobre 10, explicando el salto.

## Restricciones

- No propongas rediseños estructurales profundos.
- No propongas añadir features grandes nuevas.
- No compliques la navegación ni la arquitectura.
- Busca mejoras que puedan ejecutarse rápido.
- Prioriza impacto psicológico, claridad, fricción mínima y deseo de probar.
- Mantén un tono premium, humano, simple y confiable.
