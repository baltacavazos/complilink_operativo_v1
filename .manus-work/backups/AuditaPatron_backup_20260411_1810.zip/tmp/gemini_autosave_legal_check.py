import json
import os
import re
import requests

PROMPT = '''Responde en español, de forma breve y prudente. Evalúa esta decisión de producto:
"En un flujo de subida de documentos laborales, la app puede analizar automáticamente el archivo al seleccionarlo, pero NO lo guarda de forma definitiva hasta que el usuario acepte lo legal cuando corresponda y confirme manualmente el guardado".

Quiero que respondas estas preguntas:
1. ¿Esto debe presentarse como una obligación legal estricta? Responde sí/no y matiza.
2. ¿Por qué es prudente NO guardar automáticamente antes de aceptación y confirmación?
3. Da 3 razones concretas: cumplimiento, trazabilidad y UX/riesgo operativo.
4. Advierte si hace falta validar jurisdicción concreta antes de afirmar que "la ley lo exige".

Devuelve JSON con esta forma exacta:
{
  "strict_legal_requirement": "sí|no|depende",
  "short_answer": "...",
  "reasons": ["...", "...", "..."],
  "jurisdiction_warning": "..."
}
'''

key = os.environ['GEMINI_API_KEY']
url = f'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={key}'
payload = {
    'contents': [{'parts': [{'text': PROMPT}]}],
    'generationConfig': {
        'temperature': 0.2,
        'maxOutputTokens': 500,
        'responseMimeType': 'application/json',
    },
}
r = requests.post(url, headers={'Content-Type': 'application/json'}, json=payload, timeout=60)
r.raise_for_status()
data = r.json()
text = data['candidates'][0]['content']['parts'][0]['text']
raw_out = '/home/ubuntu/complilink_operativo_v1/tmp/gemini_autosave_legal_raw.txt'
with open(raw_out, 'w', encoding='utf-8') as f:
    f.write(text)

clean = text.strip()
match = re.search(r'\{.*\}', clean, flags=re.S)
if match:
    clean = match.group(0)

obj = json.loads(clean)
out = '/home/ubuntu/complilink_operativo_v1/tmp/gemini_autosave_legal_result.json'
with open(out, 'w', encoding='utf-8') as f:
    json.dump(obj, f, ensure_ascii=False, indent=2)
print(out)
