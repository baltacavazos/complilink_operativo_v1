import json
import os
import requests
from typing import Any, Dict

PROMPT = '''Responde en español, de forma breve y prudente. Evalúa esta decisión de producto:
"En un flujo de subida de documentos laborales, la app puede analizar automáticamente el archivo al seleccionarlo, pero NO lo guarda de forma definitiva hasta que el usuario acepte lo legal cuando corresponda y confirme manualmente el guardado".

Quiero que respondas estas preguntas:
1. ¿Esto debe presentarse como una obligación legal estricta? Responde sí/no y matiza.
2. ¿Por qué es prudente NO guardar automáticamente antes de aceptación y confirmación?
3. Da 3 razones concretas: cumplimiento, trazabilidad y UX/riesgo operativo.
4. Advierte si hace falta validar jurisdicción concreta antes de afirmar que "la ley lo exige".

Devuelve JSON con esta forma exacta:
{
  "strict_legal_requirement": "sí|no|depende",
  "short_answer": "...",
  "reasons": ["...", "...", "..."],
  "jurisdiction_warning": "..."
}
'''


def call_openai() -> Dict[str, Any]:
    key = os.environ.get('OPENAI_API_KEY')
    if not key:
        return {"error": "OPENAI_API_KEY missing"}
    url = 'https://api.openai.com/v1/chat/completions'
    payload = {
        'model': 'gpt-4.1-mini',
        'temperature': 0.2,
        'response_format': {'type': 'json_object'},
        'messages': [
            {'role': 'system', 'content': 'Eres un analista de cumplimiento y UX. No des asesoría legal concluyente sin jurisdicción.'},
            {'role': 'user', 'content': PROMPT},
        ],
        'max_tokens': 500,
    }
    r = requests.post(url, headers={'Authorization': f'Bearer {key}', 'Content-Type': 'application/json'}, json=payload, timeout=60)
    r.raise_for_status()
    data = r.json()
    return json.loads(data['choices'][0]['message']['content'])


def call_grok() -> Dict[str, Any]:
    key = os.environ.get('XAI_API_KEY')
    if not key:
        return {"error": "XAI_API_KEY missing"}
    url = 'https://api.x.ai/v1/chat/completions'
    payload = {
        'model': 'grok-3-mini',
        'temperature': 0.2,
        'response_format': {'type': 'json_object'},
        'messages': [
            {'role': 'system', 'content': 'Eres un analista de cumplimiento y UX. No des asesoría legal concluyente sin jurisdicción.'},
            {'role': 'user', 'content': PROMPT},
        ],
        'max_tokens': 500,
    }
    r = requests.post(url, headers={'Authorization': f'Bearer {key}', 'Content-Type': 'application/json'}, json=payload, timeout=60)
    r.raise_for_status()
    data = r.json()
    return json.loads(data['choices'][0]['message']['content'])


def call_gemini() -> Dict[str, Any]:
    key = os.environ.get('GEMINI_API_KEY')
    if not key:
        return {"error": "GEMINI_API_KEY missing"}
    url = f'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={key}'
    schema = {
        'type': 'OBJECT',
        'properties': {
            'strict_legal_requirement': {'type': 'STRING'},
            'short_answer': {'type': 'STRING'},
            'reasons': {'type': 'ARRAY', 'items': {'type': 'STRING'}},
            'jurisdiction_warning': {'type': 'STRING'},
        },
        'required': ['strict_legal_requirement', 'short_answer', 'reasons', 'jurisdiction_warning'],
    }
    payload = {
        'contents': [{'parts': [{'text': PROMPT}]}],
        'generationConfig': {
            'temperature': 0.2,
            'maxOutputTokens': 500,
            'responseMimeType': 'application/json',
            'responseSchema': schema,
        },
    }
    r = requests.post(url, headers={'Content-Type': 'application/json'}, json=payload, timeout=60)
    r.raise_for_status()
    data = r.json()
    text = data['candidates'][0]['content']['parts'][0]['text']
    return json.loads(text)


results = {}
for name, fn in [('chatgpt', call_openai), ('grok', call_grok), ('gemini', call_gemini)]:
    try:
        results[name] = fn()
    except Exception as exc:
        results[name] = {'error': f'{type(exc).__name__}: {exc}'}

# crude consensus synthesis
values = [v.get('strict_legal_requirement') for v in results.values() if isinstance(v, dict) and 'strict_legal_requirement' in v]
if values:
    if all(v == values[0] for v in values):
        consensus = values[0]
    elif 'depende' in values or len(set(values)) > 1:
        consensus = 'depende'
    else:
        consensus = values[0]
else:
    consensus = 'sin_datos'

summary = {
    'consensus': {
        'strict_legal_requirement': consensus,
        'models_answered': [k for k, v in results.items() if isinstance(v, dict) and 'error' not in v],
        'common_theme': 'No presentarlo como obligación legal cerrada sin jurisdicción; sí como una decisión prudente de consentimiento, trazabilidad y prevención de errores.'
    },
    'results': results,
}

out = '/home/ubuntu/complilink_operativo_v1/tmp/multi_ai_autosave_legal_check.json'
os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out, 'w', encoding='utf-8') as f:
    json.dump(summary, f, ensure_ascii=False, indent=2)

print(out)
