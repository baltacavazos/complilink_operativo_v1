import fs from 'node:fs/promises';
import path from 'node:path';

const outPath = path.resolve('/home/ubuntu/complilink_operativo_v1/tmp/auditar_lock_improvements_multi_ai_results.json');

const systemPrompt = `Eres un arquitecto senior de software. Responde en JSON estricto.`;

const userPrompt = `Contexto real del proyecto:
- Stack: React + tRPC + Express + Vitest.
- Ruta afectada: /auditar.
- Error previo ya corregido: la aceptación legal fallaba porque un named lock de MySQL no se adquiría y liberaba en la misma conexión; ahora se usa conexión dedicada.
- Nuevas mejoras aprobadas por el usuario:
  1) añadir telemetría específica para fallos de lock y tiempos de espera en /auditar,
  2) implementar reintento controlado en la UI cuando no se obtenga el lock,
  3) cubrir con pruebas E2E el envío completo del consentimiento legal.

Quiero una propuesta de implementación pragmática y robusta.
Devuelve SOLO JSON con esta forma exacta:
{
  "summary": "string breve",
  "telemetry": {
    "events": ["..."],
    "fields": ["..."],
    "server_strategy": "...",
    "ui_strategy": "..."
  },
  "retry_ui": {
    "recommended_behavior": "...",
    "max_retries": number,
    "backoff_ms": [number],
    "user_messages": ["..."],
    "guardrails": ["..."]
  },
  "e2e": {
    "scope": ["..."],
    "fixtures": ["..."],
    "assertions": ["..."]
  },
  "risks": ["..."],
  "recommended_order": ["..."],
  "confidence": "high|medium|low"
}`;

async function callOpenAI() {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error('OPENAI_API_KEY no disponible');
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: 'gpt-4.1-mini',
      response_format: { type: 'json_object' },
      temperature: 0.2,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
    }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(`OpenAI error: ${res.status} ${JSON.stringify(data)}`);
  return JSON.parse(data.choices[0].message.content);
}

async function callXAI() {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) throw new Error('XAI_API_KEY no disponible');
  const res = await fetch('https://api.x.ai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: 'grok-3-mini',
      temperature: 0.2,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
    }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(`xAI error: ${res.status} ${JSON.stringify(data)}`);
  return JSON.parse(data.choices[0].message.content);
}

async function callGemini() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error('GEMINI_API_KEY no disponible');
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      generationConfig: {
        temperature: 0.2,
        responseMimeType: 'application/json',
      },
      systemInstruction: {
        parts: [{ text: systemPrompt }],
      },
      contents: [{
        role: 'user',
        parts: [{ text: userPrompt }],
      }],
    }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(`Gemini error: ${res.status} ${JSON.stringify(data)}`);
  const text = data.candidates?.[0]?.content?.parts?.map((p) => p.text || '').join('') || '{}';
  return JSON.parse(text);
}

function summarizeConsensus(results) {
  const models = Object.keys(results).filter((k) => results[k] && !results[k].error);
  const recommendedOrder = [];
  for (const model of models) {
    const order = results[model]?.recommended_order || [];
    for (const step of order) {
      if (!recommendedOrder.includes(step)) recommendedOrder.push(step);
    }
  }
  return {
    models_consulted: models,
    consensus: {
      recommended_order: recommendedOrder,
      telemetry_events_union: [...new Set(models.flatMap((m) => results[m]?.telemetry?.events || []))],
      retry_messages_union: [...new Set(models.flatMap((m) => results[m]?.retry_ui?.user_messages || []))],
      e2e_scope_union: [...new Set(models.flatMap((m) => results[m]?.e2e?.scope || []))],
    },
  };
}

async function main() {
  const results = {};
  for (const [name, fn] of Object.entries({ chatgpt: callOpenAI, grok: callXAI, gemini: callGemini })) {
    try {
      results[name] = await fn();
    } catch (error) {
      results[name] = { error: String(error) };
    }
  }
  const payload = {
    generated_at: new Date().toISOString(),
    prompt: userPrompt,
    results,
    consensus: summarizeConsensus(results),
  };
  await fs.writeFile(outPath, JSON.stringify(payload, null, 2));
  console.log(JSON.stringify({ outPath }, null, 2));
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
