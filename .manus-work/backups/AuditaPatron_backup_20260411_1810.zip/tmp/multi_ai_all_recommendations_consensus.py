import json
import os
import requests
from datetime import datetime

PROMPT = """
Contexto: Auditapatron ya implementó en /auditar un autoanálisis seguro al seleccionar archivo o foto, sin autoguardado. Ahora el usuario aprobó tres mejoras simultáneas:
1) reforzar visualmente la distinción entre borrador analizado y documento confirmado;
2) añadir un botón único de reanalizar para repetir captura/análisis con un solo toque;
3) registrar métricas de conversión del flujo de /auditar para medir selección, análisis, confirmación y guardado.

Quiero una recomendación práctica y concisa para producto y UX mobile-first.

Devuelve JSON válido con esta forma exacta:
{
  "summary": "máximo 120 palabras",
  "priority_order": ["string", "string", "string"],
  "visual_state_recommendation": "string",
  "reanalyze_button_recommendation": "string",
  "metrics_recommendation": "string",
  "risks": ["string", "string", "string"],
  "copy_suggestions": {
    "draft_label": "string",
    "confirmed_label": "string",
    "reanalyze_cta": "string"
  }
}

Reglas:
- Responde solo JSON válido.
- Prioriza claridad, trazabilidad y UX móvil.
- No propongas autoguardado.
""".strip()


def call_openai():
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        return {"error": "OPENAI_API_KEY missing"}
    url = "https://api.openai.com/v1/chat/completions"
    payload = {
        "model": "gpt-4.1-mini",
        "temperature": 0.2,
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": "Eres un experto en producto, compliance y UX móvil. Devuelve solo JSON válido."},
            {"role": "user", "content": PROMPT},
        ],
    }
    resp = requests.post(url, headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"}, json=payload, timeout=90)
    return parse_response(resp, "openai")


def call_xai():
    key = os.environ.get("XAI_API_KEY")
    if not key:
        return {"error": "XAI_API_KEY missing"}
    url = "https://api.x.ai/v1/chat/completions"
    payload = {
        "model": "grok-3-mini",
        "temperature": 0.2,
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": "Eres un experto en producto, compliance y UX móvil. Devuelve solo JSON válido."},
            {"role": "user", "content": PROMPT},
        ],
    }
    resp = requests.post(url, headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"}, json=payload, timeout=90)
    return parse_response(resp, "xai")


def call_gemini():
    key = os.environ.get("GEMINI_API_KEY")
    if not key:
        return {"error": "GEMINI_API_KEY missing"}
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={key}"
    schema = {
        "type": "OBJECT",
        "properties": {
            "summary": {"type": "STRING"},
            "priority_order": {"type": "ARRAY", "items": {"type": "STRING"}},
            "visual_state_recommendation": {"type": "STRING"},
            "reanalyze_button_recommendation": {"type": "STRING"},
            "metrics_recommendation": {"type": "STRING"},
            "risks": {"type": "ARRAY", "items": {"type": "STRING"}},
            "copy_suggestions": {
                "type": "OBJECT",
                "properties": {
                    "draft_label": {"type": "STRING"},
                    "confirmed_label": {"type": "STRING"},
                    "reanalyze_cta": {"type": "STRING"}
                },
                "required": ["draft_label", "confirmed_label", "reanalyze_cta"]
            }
        },
        "required": [
            "summary",
            "priority_order",
            "visual_state_recommendation",
            "reanalyze_button_recommendation",
            "metrics_recommendation",
            "risks",
            "copy_suggestions"
        ]
    }
    payload = {
        "contents": [{"parts": [{"text": PROMPT}]}],
        "generationConfig": {
            "temperature": 0.2,
            "responseMimeType": "application/json",
            "responseSchema": schema,
        },
    }
    resp = requests.post(url, headers={"Content-Type": "application/json"}, json=payload, timeout=90)
    return parse_gemini_response(resp)


def parse_response(resp, provider):
    try:
        data = resp.json()
    except Exception:
        return {"error": f"{provider} invalid_json", "status": resp.status_code, "text": resp.text[:1500]}
    if resp.status_code >= 400:
        return {"error": f"{provider} http_error", "status": resp.status_code, "data": data}
    try:
        content = data["choices"][0]["message"]["content"]
        parsed = json.loads(content)
        return {"ok": True, "content": parsed}
    except Exception:
        return {"error": f"{provider} parse_error", "data": data}


def parse_gemini_response(resp):
    try:
        data = resp.json()
    except Exception:
        return {"error": "gemini invalid_json", "status": resp.status_code, "text": resp.text[:1500]}
    if resp.status_code >= 400:
        return {"error": "gemini http_error", "status": resp.status_code, "data": data}
    try:
        text = data["candidates"][0]["content"]["parts"][0]["text"]
        parsed = json.loads(text)
        return {"ok": True, "content": parsed}
    except Exception:
        return {"error": "gemini parse_error", "data": data}


def main():
    result = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "prompt": PROMPT,
        "openai": call_openai(),
        "grok": call_xai(),
        "gemini": call_gemini(),
    }
    out_path = "/home/ubuntu/complilink_operativo_v1/tmp/multi_ai_all_recommendations_consensus.json"
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(out_path)


if __name__ == "__main__":
    main()
