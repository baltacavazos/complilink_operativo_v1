import fs from 'node:fs/promises';

const errorContext = {
  page: '/auditar',
  timestamp: '2026-04-11T17:28:24.523Z',
  error: 'No se pudo asegurar la aceptación legal en este momento. Intenta de nuevo.',
  user: {
    id: 1,
    openId: 'S8ApRqTbJj4mEpPnubsWbo',
    name: 'balt',
    email: 'balt@cavazos.com',
    role: 'admin'
  }
};

const frontendExcerpt = `
Frontend (Auditar.tsx):
- Se usa trpc.consent.acceptLegalPackage.useMutation().
- handleAcceptLegalPackage() llama mutateAsync({ tenantId, caseId, accepted: true }).
- Si falla, muestra error instanceof Error ? error.message : "No fue posible registrar tu aceptación legal.".
- También invalida utils.cases.detail y utils.consent.status después del éxito.
`;

const backendExcerpt = `
Backend (server/routers.ts, mutation consent.acceptLegalPackage):
- protectedProcedure con input { tenantId, caseId, accepted: true }.
- Usa withDatabaseLock({ lockKey: legal:${'${tenantId}'}:${'${caseId}'}:${'${LEGAL_ACCEPTANCE_VERSION}'}, timeoutSeconds: 12 }).
- Obtiene detail con getCaseDetailForUser({ userId, tenantId, caseId }).
- Reconstruye consentArtifactsByType desde detail.consents solo si status === "granted" y notes.acceptanceVersion === LEGAL_ACCEPTANCE_VERSION.
- Busca contratos listCanonicalContractsByType(... contractType: "consent", schemaVersion: LEGAL_CONTRACT_SCHEMA_VERSION, status: "ready").
- Detecta eventos previos consent_updated y audit log previo.
- Si faltan consentimientos, crea addConsentRecord(...).
- Si faltan contratos, hace upsertCanonicalContract(...).
- Si falta evento, hace addCaseEvent(...).
- Si falta audit log, hace createAuditLog(...).
- Devuelve { success: true, alreadyAccepted, acceptance }.
- El error visible al usuario parece venir de una captura más arriba en la cadena tRPC, no del bloque mostrado.
`;

const prompt = `Analiza este bug real en una app React + tRPC + backend Node/TypeScript. Quiero un diagnóstico práctico y priorizado.

Contexto del error:
${JSON.stringify(errorContext, null, 2)}

${frontendExcerpt}
${backendExcerpt}

Responde SOLO en JSON válido con esta forma exacta:
{
  "model": "nombre del modelo",
  "most_likely_root_causes": [
    {
      "rank": 1,
      "cause": "texto breve",
      "why": "explicación concreta",
      "confidence": "high|medium|low",
      "specific_checks": ["check 1", "check 2"],
      "likely_fix": "cambio propuesto"
    }
  ],
  "red_flags_in_code": ["..."],
  "recommended_debug_path": ["paso 1", "paso 2", "paso 3"],
  "quick_patch_if_user_needs_immediate_relief": "..."
}
`;

async function callOpenAI() {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return { model: 'openai', error: 'OPENAI_API_KEY missing' };
  }

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: 'gpt-4.1-mini',
      temperature: 0.1,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: 'You are a senior full-stack debugging assistant. Return strict JSON only.' },
        { role: 'user', content: prompt },
      ],
    }),
  });

  const text = await response.text();
  if (!response.ok) {
    return { model: 'openai', error: text };
  }
  const data = JSON.parse(text);
  return JSON.parse(data.choices?.[0]?.message?.content ?? '{}');
}

async function callGemini() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return { model: 'gemini', error: 'GEMINI_API_KEY missing' };
  }

  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      generationConfig: {
        temperature: 0.1,
        responseMimeType: 'application/json',
      },
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
    }),
  });

  const text = await response.text();
  if (!response.ok) {
    return { model: 'gemini', error: text };
  }
  const data = JSON.parse(text);
  const content = data.candidates?.[0]?.content?.parts?.[0]?.text ?? '{}';
  return JSON.parse(content);
}

async function callGrok() {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) {
    return { model: 'grok', error: 'XAI_API_KEY missing' };
  }

  const response = await fetch('https://api.x.ai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: 'grok-4-fast-reasoning',
      temperature: 0.1,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: 'You are a senior full-stack debugging assistant. Return strict JSON only.' },
        { role: 'user', content: prompt },
      ],
    }),
  });

  const text = await response.text();
  if (!response.ok) {
    return { model: 'grok', error: text };
  }
  const data = JSON.parse(text);
  return JSON.parse(data.choices?.[0]?.message?.content ?? '{}');
}

const [openai, gemini, grok] = await Promise.allSettled([callOpenAI(), callGemini(), callGrok()]);
const results = {
  generatedAt: new Date().toISOString(),
  context: errorContext,
  openai: openai.status === 'fulfilled' ? openai.value : { model: 'openai', error: String(openai.reason) },
  gemini: gemini.status === 'fulfilled' ? gemini.value : { model: 'gemini', error: String(gemini.reason) },
  grok: grok.status === 'fulfilled' ? grok.value : { model: 'grok', error: String(grok.reason) },
};

await fs.mkdir('/home/ubuntu/complilink_operativo_v1/tmp', { recursive: true });
await fs.writeFile('/home/ubuntu/complilink_operativo_v1/tmp/legal_acceptance_multi_ai_results.json', JSON.stringify(results, null, 2));
console.log(JSON.stringify(results, null, 2));
