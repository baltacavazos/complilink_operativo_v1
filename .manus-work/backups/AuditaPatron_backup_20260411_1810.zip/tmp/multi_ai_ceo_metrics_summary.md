# Síntesis multi-IA para el siguiente bloque CEO

La consulta a **ChatGPT, Grok y Gemini** coincidió en cuatro puntos prácticos. Primero, el **panel maestro** debe ser una superficie pequeña, visible sólo para el usuario administrador principal, apoyada en la misma autenticación y en procedimientos tRPC ya existentes o muy cercanos. Segundo, las métricas más útiles para esta iteración mínima son: entradas a la consola CEO, exportaciones ejecutadas y secciones más usadas. Tercero, los **bloqueos de guardrails** deben persistirse con motivo y ubicación para diagnóstico, idealmente reutilizando la infraestructura de auditoría. Cuarto, las pruebas mínimas deben cubrir visibilidad por rol, persistencia de eventos y no regresión sobre exportes ni conmutación CEO ↔ vista usuario.

## Coincidencias operativas

| Fuente | Recomendación central | Lectura para implementación |
| --- | --- | --- |
| ChatGPT | Reutilizar tRPC y auditoría existente; métricas simples y chequeo doble de rol | Conviene evitar un rediseño y construir una consulta agregada pequeña |
| Grok | Mantener el panel como sección compacta o toggle; registrar bloqueos en auditoría existente o extensión mínima | Encaja con una tarjeta adicional dentro de `CeoDashboard` |
| Gemini | Priorizar persistencia de guardrails y exponer agregados para el panel maestro | Sugiere una única fuente de verdad basada en eventos auditados |

## Hallazgo técnico local

El proyecto ya dispone de `audit_logs` con `action`, `entityType`, `entityId`, `beforeState`, `afterState` y `createdAt`, además de `createAuditLog()` y `listAuditTrail()`. También existe `dashboard.ceoRecordExportAudit`, que ya persiste `dashboard.ceo.export_generated` con `section`, `format`, `snapshotGeneratedAt`, `appliedFilters` y `visibleCount`. Por lo tanto, para esta iteración conviene **reutilizar `audit_logs`** en lugar de abrir una migración nueva. La pieza faltante parece ser persistir eventos para `dashboard.ceo.viewed` y `dashboard.ceo.guardrail_blocked`, y luego agregar una consulta administrativa resumida.

## Decisión de implementación sugerida

| Área | Decisión |
| --- | --- |
| Panel maestro | Crear un bloque compacto dentro de `CeoDashboard`, visible sólo para el administrador principal |
| Persistencia | Reusar `audit_logs` con nuevas acciones `dashboard.ceo.viewed` y `dashboard.ceo.guardrail_blocked` |
| Agregación | Añadir un procedimiento tRPC administrativo que resuma entradas, exportaciones, secciones top y bloqueos recientes |
| Pruebas | Vitest para agregación/persistencia y Playwright para stale snapshot, retry y visibilidad del panel |

## Riesgo relevante

El mayor riesgo no es de interfaz sino de **autorización**: el panel no debe quedar visible por un simple chequeo visual en frontend. Debe existir también un control fuerte en backend sobre el procedimiento de métricas, idealmente limitado al administrador principal.
